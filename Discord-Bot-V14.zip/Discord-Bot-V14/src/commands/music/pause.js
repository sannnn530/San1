module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const success = client.musicPause(interaction.guild.id);
    
    if (!success) {
        return client.errNormal({ error: "There is no music playing or it's already paused!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: "Paused the music!", type: 'editreply' }, interaction);
};
