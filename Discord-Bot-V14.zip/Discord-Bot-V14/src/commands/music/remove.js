module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const position = interaction.options.getNumber('number');
    const removed = client.musicRemove(interaction.guild.id, position);
    
    if (!removed) {
        return client.errNormal({ error: "Invalid position or no queue!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: `Removed **${removed.title}** from the queue!`, type: 'editreply' }, interaction);
};
