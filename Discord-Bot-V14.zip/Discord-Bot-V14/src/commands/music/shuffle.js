module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const success = client.musicShuffle(interaction.guild.id);
    
    if (!success) {
        return client.errNormal({ error: "Not enough songs in the queue to shuffle!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: "Shuffled the queue!", type: 'editreply' }, interaction);
};
