module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const success = client.musicStop(interaction.guild.id);
    
    if (!success) {
        return client.errNormal({ error: "There is no music playing!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: "Stopped the music and cleared the queue!", type: 'editreply' }, interaction);
};
