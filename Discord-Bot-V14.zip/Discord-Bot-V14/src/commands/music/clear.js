module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const success = client.musicClear(interaction.guild.id);
    
    if (!success) {
        return client.errNormal({ error: "There is no music playing!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: "Cleared the queue! Current song will continue.", type: 'editreply' }, interaction);
};
