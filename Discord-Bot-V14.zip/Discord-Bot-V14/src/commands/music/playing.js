module.exports = async (client, interaction, args) => {
    const song = client.musicNowPlaying(interaction.guild.id);
    
    if (!song) {
        return client.errNormal({ error: "There is no music playing!", type: 'editreply' }, interaction);
    }

    client.embed({
        title: `${client.emotes.normal.music}・Now Playing`,
        desc: `**[${song.title}](${song.url})**`,
        thumbnail: song.thumbnail,
        fields: [
            { name: "Duration", value: song.duration || 'Unknown', inline: true },
            { name: "Requested By", value: `${song.requestedBy}`, inline: true }
        ],
        type: 'editreply'
    }, interaction);
};
