module.exports = async (client, interaction, args) => {
    const songs = client.musicQueue(interaction.guild.id);
    
    if (!songs || songs.length === 0) {
        return client.errNormal({ error: "The queue is empty!", type: 'editreply' }, interaction);
    }

    const queueList = songs.slice(0, 10).map((song, index) => {
        if (index === 0) {
            return `**Now Playing:** [${song.title}](${song.url}) - \`${song.duration}\``;
        }
        return `**${index}.** [${song.title}](${song.url}) - \`${song.duration}\``;
    }).join('\n');

    const totalSongs = songs.length;

    client.embed({
        title: `${client.emotes.normal.music}・Music Queue`,
        desc: queueList + (totalSongs > 10 ? `\n\n*...and ${totalSongs - 10} more songs*` : ''),
        fields: [
            { name: "Total Songs", value: `${totalSongs}`, inline: true }
        ],
        type: 'editreply'
    }, interaction);
};
