module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const loopStatus = client.musicLoop(interaction.guild.id);
    
    if (loopStatus === null) {
        return client.errNormal({ error: "There is no music playing!", type: 'editreply' }, interaction);
    }

    client.succNormal({ 
        text: loopStatus ? "Loop enabled! The current song will repeat." : "Loop disabled!", 
        type: 'editreply' 
    }, interaction);
};
