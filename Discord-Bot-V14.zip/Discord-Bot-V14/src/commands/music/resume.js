module.exports = async (client, interaction, args) => {
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const success = client.musicResume(interaction.guild.id);
    
    if (!success) {
        return client.errNormal({ error: "There is no music paused!", type: 'editreply' }, interaction);
    }

    client.succNormal({ text: "Resumed the music!", type: 'editreply' }, interaction);
};
