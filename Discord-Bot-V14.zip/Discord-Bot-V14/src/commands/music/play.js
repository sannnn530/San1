const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const query = interaction.options.getString('song');
    
    if (!interaction.member.voice.channel) {
        return client.errNormal({ error: "You must be in a voice channel!", type: 'editreply' }, interaction);
    }

    const result = await client.play(interaction, query);
    
    if (!result.success) {
        return client.errNormal({ error: result.error, type: 'editreply' }, interaction);
    }

    if (result.isPlaylist) {
        return client.embed({
            title: `${client.emotes.normal.music}・Playlist Added`,
            desc: `Added **${result.playlistCount}** songs to the queue!`,
            type: 'editreply'
        }, interaction);
    }

    client.embed({
        title: `${client.emotes.normal.music}・Added to Queue`,
        desc: `**[${result.song.title}](${result.song.url})**`,
        thumbnail: result.song.thumbnail,
        fields: [
            { name: "Duration", value: result.song.duration || 'Unknown', inline: true },
            { name: "Position", value: `${result.position}`, inline: true },
            { name: "Requested By", value: `${result.song.requestedBy}`, inline: true }
        ],
        type: 'editreply'
    }, interaction);
};
