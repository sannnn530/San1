const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    const cardEmojis = ['🎯', '⭐', '💎', '🔥', '🌙', '🌸', '🎭', '🎪'];
    let cards = [];
    let revealed = [];
    let matched = [];
    let firstCard = null;
    let moves = 0;
    let score = 0;

    function shuffle(array) {
        const arr = [...array];
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [arr[i], arr[j]] = [arr[j], arr[i]];
        }
        return arr;
    }

    function initGame() {
        const selectedEmojis = shuffle(cardEmojis).slice(0, 6);
        const pairs = [...selectedEmojis, ...selectedEmojis];
        cards = shuffle(pairs);
        revealed = new Array(12).fill(false);
        matched = new Array(12).fill(false);
    }

    function createGrid() {
        const rows = [];
        for (let row = 0; row < 3; row++) {
            const buttons = [];
            for (let col = 0; col < 4; col++) {
                const idx = row * 4 + col;
                const btn = new Discord.ButtonBuilder()
                    .setCustomId(`memory_${idx}`);

                if (matched[idx]) {
                    btn.setEmoji('✅')
                        .setStyle(Discord.ButtonStyle.Success)
                        .setDisabled(true);
                } else if (revealed[idx]) {
                    btn.setEmoji(cards[idx])
                        .setStyle(Discord.ButtonStyle.Primary);
                } else {
                    btn.setEmoji('❓')
                        .setStyle(Discord.ButtonStyle.Secondary);
                }
                buttons.push(btn);
            }
            rows.push(new Discord.ActionRowBuilder().addComponents(buttons));
        }
        return rows;
    }

    function createEmbed(message) {
        const matchedCount = matched.filter(m => m).length / 2;
        return new Discord.EmbedBuilder()
            .setTitle('🎴 Memory Match')
            .setDescription(message)
            .addFields(
                { name: '🎯 Pairs Found', value: `${matchedCount}/6`, inline: true },
                { name: '👆 Moves', value: `${moves}`, inline: true },
                { name: '💰 Score', value: `$${score}`, inline: true }
            )
            .setColor('#9b59b6');
    }

    async function startGame() {
        initGame();

        await interaction.editReply({
            embeds: [createEmbed('Find all matching pairs!\n\nClick cards to reveal them.')],
            components: createGrid()
        });

        const collector = interaction.channel.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id && i.customId.startsWith('memory_'),
            time: 120000
        });

        collector.on('collect', async (i) => {
            const idx = parseInt(i.customId.split('_')[1]);

            if (matched[idx] || revealed[idx]) {
                return i.deferUpdate();
            }

            revealed[idx] = true;

            if (firstCard === null) {
                firstCard = idx;
                await i.update({
                    embeds: [createEmbed('Card revealed! Pick another card.')],
                    components: createGrid()
                });
            } else {
                moves++;
                const secondCard = idx;

                await i.update({
                    embeds: [createEmbed('Checking...')],
                    components: createGrid()
                });

                if (cards[firstCard] === cards[secondCard]) {
                    matched[firstCard] = true;
                    matched[secondCard] = true;
                    
                    const reward = Math.max(50, 150 - (moves * 5));
                    score += reward;

                    revealed[firstCard] = false;
                    revealed[secondCard] = false;

                    const matchedCount = matched.filter(m => m).length / 2;

                    if (matchedCount === 6) {
                        collector.stop('win');

                        const bonus = Math.max(0, 300 - (moves * 10));
                        const totalScore = score + bonus;

                        await Schema.findOneAndUpdate(
                            { Guild: interaction.guild.id, User: interaction.user.id },
                            { $inc: { Money: totalScore } },
                            { upsert: true }
                        );

                        await interaction.editReply({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle('🎉 You Win!')
                                .setDescription(`All pairs matched in **${moves}** moves!\n\n💰 Match Rewards: $${score}\n⭐ Speed Bonus: +$${bonus}\n\n**Total:** $${totalScore.toLocaleString()}`)
                                .setColor('#2ecc71')
                            ],
                            components: []
                        });
                    } else {
                        await new Promise(r => setTimeout(r, 500));
                        await interaction.editReply({
                            embeds: [createEmbed(`✅ Match found! +$${reward}`)],
                            components: createGrid()
                        });
                    }
                } else {
                    await new Promise(r => setTimeout(r, 1000));
                    revealed[firstCard] = false;
                    revealed[secondCard] = false;
                    await interaction.editReply({
                        embeds: [createEmbed('❌ No match! Cards hidden.')],
                        components: createGrid()
                    });
                }

                firstCard = null;
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                if (score > 0) {
                    await Schema.findOneAndUpdate(
                        { Guild: interaction.guild.id, User: interaction.user.id },
                        { $inc: { Money: score } },
                        { upsert: true }
                    );
                }

                await interaction.editReply({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('⏰ Time Up!')
                        .setDescription(`Game ended!\n\n💰 **Earned:** $${score.toLocaleString()}`)
                        .setColor('#95a5a6')
                    ],
                    components: []
                });
            }
        });
    }

    await startGame();
};
