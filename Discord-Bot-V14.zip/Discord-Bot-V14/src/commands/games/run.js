const Discord = require('discord.js');

const gameCategories = [
    {
        name: '💰 Economy Games',
        games: [
            { name: 'Forage', value: 'forage', emoji: '🌿', description: 'Search areas for treasures with mini-games' },
            { name: 'Tsunami Escape', value: 'tsunami', emoji: '🌊', description: 'Survive the waves and earn rewards' },
            { name: 'Brain Rod', value: 'brainrod', emoji: '🧠', description: 'Solve puzzles for money' },
            { name: 'Word Scramble', value: 'wordscramble', emoji: '🔤', description: 'Unscramble words for cash' },
            { name: 'Reaction Race', value: 'reaction', emoji: '⚡', description: 'Test your reaction speed' },
            { name: 'Number Guess', value: 'numberguess', emoji: '🔢', description: 'Guess the secret number' },
            { name: 'Memory Match', value: 'memorymatch', emoji: '🎴', description: 'Match pairs to win' },
            { name: 'High Low', value: 'highlow', emoji: '📊', description: 'Guess higher or lower' },
            { name: 'Coin Flip', value: 'coinflip', emoji: '🪙', description: 'Bet on heads or tails' }
        ]
    },
    {
        name: '🎲 Classic Games',
        games: [
            { name: 'Trivia', value: 'trivia', emoji: '❓', description: 'Answer trivia questions' },
            { name: 'Rock Paper Scissors', value: 'rps', emoji: '✂️', description: 'Play against the bot' },
            { name: '8 Ball', value: '8ball', emoji: '🎱', description: 'Ask a question' },
            { name: 'Roll Dice', value: 'roll', emoji: '🎲', description: 'Roll a die' },
            { name: 'Snake', value: 'snake', emoji: '🐍', description: 'Classic snake game' },
            { name: 'Hangman', value: 'hangman', emoji: '📜', description: 'Guess the word' },
            { name: 'Tic-Tac-Toe', value: 'tictactoe', emoji: '❌', description: 'Play against the bot' },
            { name: 'Color Guess', value: 'colorguess', emoji: '🎨', description: 'Identify colors quickly' }
        ]
    },
    {
        name: '🗣️ Social Games',
        games: [
            { name: 'Would You Rather', value: 'wouldyourather', emoji: '🤔', description: 'Choose between two options' },
            { name: 'Will You Press', value: 'willyoupressthebutton', emoji: '🔴', description: 'Press the button?' },
            { name: 'Fast Type', value: 'fasttype', emoji: '⌨️', description: 'Typing speed test' }
        ]
    }
];

module.exports = async (client, interaction, args) => {
    const allGames = gameCategories.flatMap(cat => cat.games);
    
    const categorySelect = new Discord.StringSelectMenuBuilder()
        .setCustomId('gameCategory')
        .setPlaceholder('Select a game category...')
        .addOptions(gameCategories.map(cat => ({
            label: cat.name,
            value: cat.name,
            description: `${cat.games.length} games`
        })));

    const quickPlayGames = ['forage', 'tsunami', 'brainrod', 'wordscramble', 'reaction', 'numberguess', 'memorymatch'];
    const quickButtons = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_random')
            .setLabel('🎲 Random Game')
            .setStyle(Discord.ButtonStyle.Success),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_forage')
            .setLabel('🌿 Forage')
            .setStyle(Discord.ButtonStyle.Primary),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_tsunami')
            .setLabel('🌊 Tsunami')
            .setStyle(Discord.ButtonStyle.Primary),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_brainrod')
            .setLabel('🧠 Brain Rod')
            .setStyle(Discord.ButtonStyle.Primary)
    );

    const quickButtons2 = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_wordscramble')
            .setLabel('🔤 Word Scramble')
            .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_reaction')
            .setLabel('⚡ Reaction')
            .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_numberguess')
            .setLabel('🔢 Number Guess')
            .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
            .setCustomId('quickplay_memorymatch')
            .setLabel('🎴 Memory')
            .setStyle(Discord.ButtonStyle.Secondary)
    );

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('🎮 Game Hub')
            .setDescription('**Quick Play** - Click a button to start immediately!\n\nOr use the dropdown to browse all games by category.')
            .addFields(
                gameCategories.map(cat => ({
                    name: cat.name,
                    value: cat.games.map(g => `${g.emoji} ${g.name}`).join(', '),
                    inline: false
                }))
            )
            .setColor('#9b59b6')
            .setFooter({ text: 'Select a category or quick play a game!' })
        ],
        components: [
            quickButtons,
            quickButtons2,
            new Discord.ActionRowBuilder().addComponents(categorySelect)
        ]
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id,
        time: 60000
    });

    collector.on('collect', async (i) => {
        if (i.customId.startsWith('quickplay_')) {
            collector.stop();
            let gameName = i.customId.replace('quickplay_', '');
            
            if (gameName === 'random') {
                gameName = quickPlayGames[Math.floor(Math.random() * quickPlayGames.length)];
            }

            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('🎮 Loading Game...')
                    .setDescription(`Starting **${gameName}**...`)
                    .setColor('#3498db')
                ],
                components: []
            });

            try {
                const gameModule = require(`./${gameName}.js`);
                await gameModule(client, interaction, args);
            } catch (err) {
                try {
                    await interaction.editReply({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('❌ Game Not Found')
                            .setDescription(`The game **${gameName}** is not available yet!`)
                            .setColor('#e74c3c')
                        ],
                        components: []
                    });
                } catch (e) {}
            }
        }

        if (i.customId === 'gameCategory') {
            const category = gameCategories.find(c => c.name === i.values[0]);
            
            const gameSelect = new Discord.StringSelectMenuBuilder()
                .setCustomId('gameSelect')
                .setPlaceholder('Select a game to play...')
                .addOptions(category.games.map(g => ({
                    label: g.name,
                    value: g.value,
                    emoji: g.emoji,
                    description: g.description
                })));

            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`${category.name}`)
                    .setDescription(category.games.map(g => `${g.emoji} **${g.name}** - ${g.description}`).join('\n'))
                    .setColor('#9b59b6')
                ],
                components: [
                    new Discord.ActionRowBuilder().addComponents(gameSelect),
                    new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId('backToHub')
                            .setLabel('◀️ Back to Hub')
                            .setStyle(Discord.ButtonStyle.Secondary)
                    )
                ]
            });
        }

        if (i.customId === 'gameSelect') {
            collector.stop();
            const gameName = i.values[0];

            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('🎮 Loading Game...')
                    .setDescription(`Starting **${gameName}**...`)
                    .setColor('#3498db')
                ],
                components: []
            });

            try {
                const gameModule = require(`./${gameName}.js`);
                await gameModule(client, interaction, args);
            } catch (err) {
                try {
                    await interaction.editReply({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('❌ Game Not Found')
                            .setDescription(`The game **${gameName}** is not available yet!\nUse \`/games ${gameName}\` directly.`)
                            .setColor('#e74c3c')
                        ],
                        components: []
                    });
                } catch (e) {}
            }
        }

        if (i.customId === 'backToHub') {
            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('🎮 Game Hub')
                    .setDescription('**Quick Play** - Click a button to start immediately!\n\nOr use the dropdown to browse all games by category.')
                    .addFields(
                        gameCategories.map(cat => ({
                            name: cat.name,
                            value: cat.games.map(g => `${g.emoji} ${g.name}`).join(', '),
                            inline: false
                        }))
                    )
                    .setColor('#9b59b6')
                ],
                components: [
                    quickButtons,
                    quickButtons2,
                    new Discord.ActionRowBuilder().addComponents(categorySelect)
                ]
            });
        }
    });
};
