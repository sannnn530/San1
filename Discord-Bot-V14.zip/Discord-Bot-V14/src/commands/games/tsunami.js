const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const escapeActions = [
    { name: 'Run to higher ground', emoji: '🏃', success: 0.7, reward: 100 },
    { name: 'Climb a tree', emoji: '🌳', success: 0.6, reward: 150 },
    { name: 'Find a boat', emoji: '🚤', success: 0.5, reward: 250 },
    { name: 'Hide in building', emoji: '🏢', success: 0.4, reward: 300 },
    { name: 'Surf the wave', emoji: '🏄', success: 0.2, reward: 1000 }
];

const hazards = [
    { name: 'Debris', emoji: '🪵', damage: 1 },
    { name: 'Strong current', emoji: '🌊', damage: 1 },
    { name: 'Falling rocks', emoji: '🪨', damage: 2 },
    { name: 'Whirlpool', emoji: '🌀', damage: 2 },
    { name: 'Shark', emoji: '🦈', damage: 3 }
];

const bonuses = [
    { name: 'Life jacket', emoji: '🦺', effect: '+1 life' },
    { name: 'Rescue helicopter', emoji: '🚁', effect: 'Instant escape!' },
    { name: 'Gold coins', emoji: '💰', effect: '+$500 bonus' },
    { name: 'Treasure chest', emoji: '🪙', effect: '+$1000 bonus' }
];

module.exports = async (client, interaction, args) => {
    let lives = 3;
    let totalReward = 0;
    let round = 0;
    let escaped = false;
    let tsunamiLevel = 1;

    const updateEmbed = (status, description, color) => {
        return new Discord.EmbedBuilder()
            .setTitle(`🌊 Tsunami Escape - Wave ${tsunamiLevel}`)
            .setDescription(description)
            .addFields(
                { name: '❤️ Lives', value: lives > 0 ? '❤️'.repeat(lives) : '💀', inline: true },
                { name: '💰 Rewards', value: `$${totalReward.toLocaleString()}`, inline: true },
                { name: '🌊 Wave Level', value: `${tsunamiLevel}`, inline: true }
            )
            .setColor(color)
            .setFooter({ text: status });
    };

    const actionButtons = () => {
        const rows = [];
        const buttons1 = escapeActions.slice(0, 3).map(a => 
            new Discord.ButtonBuilder()
                .setCustomId(`tsunami_${a.name}`)
                .setLabel(`${a.emoji} ${a.name}`)
                .setStyle(Discord.ButtonStyle.Primary)
        );
        const buttons2 = escapeActions.slice(3).map(a => 
            new Discord.ButtonBuilder()
                .setCustomId(`tsunami_${a.name}`)
                .setLabel(`${a.emoji} ${a.name}`)
                .setStyle(Discord.ButtonStyle.Danger)
        );
        rows.push(new Discord.ActionRowBuilder().addComponents(buttons1));
        if (buttons2.length > 0) rows.push(new Discord.ActionRowBuilder().addComponents(buttons2));
        return rows;
    };

    await interaction.editReply({
        embeds: [updateEmbed('Choose your escape action!', '🌊 **A massive tsunami is approaching!**\n\nChoose how you want to escape. Riskier actions have bigger rewards but lower success rates!\n\n🏃 Safe options = Higher success, lower reward\n🏄 Risky options = Lower success, higher reward', '#3498db')],
        components: actionButtons()
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('tsunami_'),
        time: 60000
    });

    collector.on('collect', async (i) => {
        const actionName = i.customId.replace('tsunami_', '');
        const action = escapeActions.find(a => a.name === actionName);
        
        if (!action) return;

        round++;
        const adjustedSuccess = Math.max(0.1, action.success - (tsunamiLevel * 0.05));
        const success = Math.random() < adjustedSuccess;

        if (success) {
            const bonusRoll = Math.random();
            let bonusText = '';
            
            if (bonusRoll < 0.1) {
                const bonus = bonuses[Math.floor(Math.random() * bonuses.length)];
                bonusText = `\n\n🎁 **BONUS:** ${bonus.emoji} ${bonus.name} - ${bonus.effect}`;
                
                if (bonus.effect === '+1 life') lives = Math.min(5, lives + 1);
                if (bonus.effect === '+$500 bonus') totalReward += 500;
                if (bonus.effect === '+$1000 bonus') totalReward += 1000;
                if (bonus.effect === 'Instant escape!') {
                    escaped = true;
                    totalReward += action.reward * 2;
                }
            }

            if (!escaped) {
                totalReward += Math.floor(action.reward * (1 + tsunamiLevel * 0.2));
                tsunamiLevel++;
            }

            if (escaped || tsunamiLevel > 5) {
                collector.stop('escaped');
                
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: totalReward } },
                    { upsert: true }
                );

                return i.update({
                    embeds: [updateEmbed('YOU ESCAPED!', `${action.emoji} You successfully ${action.name.toLowerCase()}!\n\n🎉 **VICTORY!**\nYou survived the tsunami and earned **$${totalReward.toLocaleString()}**!${bonusText}`, '#2ecc71')],
                    components: []
                });
            }

            await i.update({
                embeds: [updateEmbed('The wave grows stronger...', `${action.emoji} **Success!** You ${action.name.toLowerCase()}!\n+$${Math.floor(action.reward * (1 + (tsunamiLevel-1) * 0.2)).toLocaleString()}${bonusText}\n\n🌊 But another wave is coming! Wave ${tsunamiLevel} approaches...`, '#f39c12')],
                components: actionButtons()
            });

        } else {
            const hazard = hazards[Math.floor(Math.random() * hazards.length)];
            lives -= hazard.damage;

            if (lives <= 0) {
                collector.stop('died');
                const lostReward = Math.floor(totalReward * 0.5);
                
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: lostReward } },
                    { upsert: true }
                );

                return i.update({
                    embeds: [updateEmbed('GAME OVER', `${action.emoji} You tried to ${action.name.toLowerCase()} but failed!\n\n${hazard.emoji} **${hazard.name}** hit you!\n\n💀 **You were swept away by the tsunami...**\n\nYou managed to save **$${lostReward.toLocaleString()}** (50% of earnings)`, '#e74c3c')],
                    components: []
                });
            }

            await i.update({
                embeds: [updateEmbed('Keep going!', `${action.emoji} You tried to ${action.name.toLowerCase()} but failed!\n\n${hazard.emoji} **${hazard.name}** hit you! (-${hazard.damage} ❤️)\n\n⚠️ ${lives} lives remaining. Try another escape!`, '#e74c3c')],
                components: actionButtons()
            });
        }
    });

    collector.on('end', (collected, reason) => {
        if (reason === 'time') {
            interaction.editReply({
                embeds: [updateEmbed('TIMED OUT', '⏰ You hesitated too long and the tsunami caught you!\n\nNo rewards earned.', '#95a5a6')],
                components: []
            }).catch(() => {});
        }
    });
};
