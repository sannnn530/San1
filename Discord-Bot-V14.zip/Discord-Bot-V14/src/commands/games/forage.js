const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const forageAreas = [
    { name: 'Forest', emoji: '🌲', items: [
        { name: 'Mushroom', emoji: '🍄', value: 15, chance: 30 },
        { name: 'Berries', emoji: '🫐', value: 10, chance: 35 },
        { name: 'Acorn', emoji: '🌰', value: 5, chance: 40 },
        { name: 'Wild Honey', emoji: '🍯', value: 50, chance: 10 },
        { name: 'Rare Truffle', emoji: '🟤', value: 200, chance: 3 },
        { name: 'Golden Leaf', emoji: '🍂', value: 500, chance: 1 }
    ]},
    { name: 'Beach', emoji: '🏖️', items: [
        { name: 'Seashell', emoji: '🐚', value: 8, chance: 35 },
        { name: 'Starfish', emoji: '⭐', value: 20, chance: 25 },
        { name: 'Sea Glass', emoji: '💎', value: 35, chance: 20 },
        { name: 'Pearl', emoji: '🫧', value: 150, chance: 5 },
        { name: 'Message Bottle', emoji: '🍾', value: 300, chance: 2 },
        { name: 'Treasure Chest', emoji: '🪙', value: 1000, chance: 0.5 }
    ]},
    { name: 'Mountain', emoji: '🏔️', items: [
        { name: 'Rock', emoji: '🪨', value: 5, chance: 40 },
        { name: 'Crystal', emoji: '💠', value: 40, chance: 20 },
        { name: 'Fossil', emoji: '🦴', value: 75, chance: 12 },
        { name: 'Gemstone', emoji: '💎', value: 200, chance: 5 },
        { name: 'Ancient Relic', emoji: '🏺', value: 500, chance: 2 },
        { name: 'Dragon Scale', emoji: '🐉', value: 2000, chance: 0.3 }
    ]},
    { name: 'Swamp', emoji: '🐸', items: [
        { name: 'Lily Pad', emoji: '🌿', value: 8, chance: 35 },
        { name: 'Frog', emoji: '🐸', value: 25, chance: 25 },
        { name: 'Moss Ball', emoji: '🟢', value: 15, chance: 30 },
        { name: 'Glow Worm', emoji: '✨', value: 100, chance: 8 },
        { name: 'Witch Herb', emoji: '🧙', value: 350, chance: 3 },
        { name: 'Swamp Diamond', emoji: '💚', value: 1500, chance: 0.4 }
    ]}
];

const miniGames = [
    { name: 'Quick Catch', type: 'reaction' },
    { name: 'Spot the Item', type: 'spot' },
    { name: 'Memory Hunt', type: 'memory' },
    { name: 'Shake the Bush', type: 'shake' }
];

function selectItem(items) {
    const roll = Math.random() * 100;
    let cumulative = 0;
    for (const item of items.sort((a, b) => b.chance - a.chance)) {
        cumulative += item.chance;
        if (roll <= cumulative) return item;
    }
    return items[0];
}

function shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

module.exports = async (client, interaction, args) => {
    const areaOptions = forageAreas.map(a => ({
        label: `${a.emoji} ${a.name}`,
        value: a.name.toLowerCase(),
        description: `Search the ${a.name.toLowerCase()} for items`
    }));

    const areaSelect = new Discord.ActionRowBuilder().addComponents(
        new Discord.StringSelectMenuBuilder()
            .setCustomId('forageArea')
            .setPlaceholder('Choose an area to forage...')
            .addOptions(areaOptions)
    );

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('🌿 Foraging Adventure')
            .setDescription('Choose an area to search for items!\n\nComplete mini-games to find treasures!')
            .setColor('#2ecc71')
        ],
        components: [areaSelect]
    });

    const filter = i => i.user.id === interaction.user.id;
    
    try {
        const areaInteraction = await interaction.channel.awaitMessageComponent({ 
            filter: i => filter(i) && i.customId === 'forageArea', 
            time: 30000 
        });
        
        const selectedArea = forageAreas.find(a => a.name.toLowerCase() === areaInteraction.values[0]);
        const foundItems = [];
        let totalRounds = 3;
        let currentRound = 0;

        async function runMiniGame(inter) {
            currentRound++;
            const game = miniGames[Math.floor(Math.random() * miniGames.length)];
            
            if (game.type === 'reaction') {
                const targetItem = selectItem(selectedArea.items);
                const decoyEmojis = ['❌', '🚫', '⛔', '🔴', '💢'];
                const positions = shuffle([0, 1, 2, 3, 4]);
                const correctPos = positions[0];
                
                const buttons = positions.map((pos, idx) => 
                    new Discord.ButtonBuilder()
                        .setCustomId(`forage_catch_${idx}`)
                        .setEmoji(idx === correctPos ? targetItem.emoji : decoyEmojis[Math.floor(Math.random() * decoyEmojis.length)])
                        .setStyle(Discord.ButtonStyle.Secondary)
                );

                await inter.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`🎯 Quick Catch! (Round ${currentRound}/${totalRounds})`)
                        .setDescription(`**Find the ${targetItem.emoji} ${targetItem.name}!**\n\nClick quickly before it escapes!`)
                        .setColor('#f39c12')
                    ],
                    components: [new Discord.ActionRowBuilder().addComponents(buttons)]
                });

                try {
                    const catchInt = await interaction.channel.awaitMessageComponent({
                        filter: i => filter(i) && i.customId.startsWith('forage_catch_'),
                        time: 5000
                    });

                    const clicked = parseInt(catchInt.customId.split('_')[2]);
                    if (clicked === correctPos) {
                        foundItems.push(targetItem);
                        if (currentRound < totalRounds) {
                            await runMiniGame(catchInt);
                        } else {
                            await finishForaging(catchInt);
                        }
                    } else {
                        if (currentRound < totalRounds) {
                            await catchInt.update({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('❌ Missed!')
                                    .setDescription(`The ${targetItem.name} got away!\n\nNext round starting...`)
                                    .setColor('#e74c3c')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging(catchInt);
                        }
                    }
                } catch (e) {
                    if (currentRound < totalRounds) {
                        await interaction.editReply({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle('⏰ Too Slow!')
                                .setDescription('It escaped! Next round...')
                                .setColor('#e74c3c')
                            ],
                            components: []
                        });
                        await new Promise(r => setTimeout(r, 1500));
                        await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                    } else {
                        await finishForaging({ update: (opts) => interaction.editReply(opts) });
                    }
                }

            } else if (game.type === 'spot') {
                const targetItem = selectItem(selectedArea.items);
                const similarEmojis = ['🌿', '🍃', '🌱', '☘️', '🪴'];
                const gridSize = 9;
                const correctPos = Math.floor(Math.random() * gridSize);
                
                const buttons = [];
                for (let i = 0; i < gridSize; i++) {
                    buttons.push(
                        new Discord.ButtonBuilder()
                            .setCustomId(`forage_spot_${i}`)
                            .setEmoji(i === correctPos ? targetItem.emoji : similarEmojis[Math.floor(Math.random() * similarEmojis.length)])
                            .setStyle(Discord.ButtonStyle.Secondary)
                    );
                }

                const rows = [
                    new Discord.ActionRowBuilder().addComponents(buttons.slice(0, 3)),
                    new Discord.ActionRowBuilder().addComponents(buttons.slice(3, 6)),
                    new Discord.ActionRowBuilder().addComponents(buttons.slice(6, 9))
                ];

                await inter.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`👀 Spot the Item! (Round ${currentRound}/${totalRounds})`)
                        .setDescription(`**Find the hidden ${targetItem.emoji} ${targetItem.name}!**\n\nLook carefully in the foliage...`)
                        .setColor('#9b59b6')
                    ],
                    components: rows
                });

                try {
                    const spotInt = await interaction.channel.awaitMessageComponent({
                        filter: i => filter(i) && i.customId.startsWith('forage_spot_'),
                        time: 8000
                    });

                    const clicked = parseInt(spotInt.customId.split('_')[2]);
                    if (clicked === correctPos) {
                        foundItems.push(targetItem);
                        if (currentRound < totalRounds) {
                            await runMiniGame(spotInt);
                        } else {
                            await finishForaging(spotInt);
                        }
                    } else {
                        if (currentRound < totalRounds) {
                            await spotInt.update({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('❌ Wrong Spot!')
                                    .setDescription(`That wasn't the ${targetItem.name}!\n\nNext round...`)
                                    .setColor('#e74c3c')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging(spotInt);
                        }
                    }
                } catch (e) {
                    if (currentRound < totalRounds) {
                        await interaction.editReply({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle('⏰ Time Up!')
                                .setDescription('You looked too long! Next round...')
                                .setColor('#e74c3c')
                            ],
                            components: []
                        });
                        await new Promise(r => setTimeout(r, 1500));
                        await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                    } else {
                        await finishForaging({ update: (opts) => interaction.editReply(opts) });
                    }
                }

            } else if (game.type === 'shake') {
                const targetItem = selectItem(selectedArea.items);
                const requiredShakes = 3 + Math.floor(Math.random() * 3);
                let shakeCount = 0;
                
                const shakeButton = () => new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('forage_shake')
                        .setLabel(`🌳 Shake! (${shakeCount}/${requiredShakes})`)
                        .setStyle(Discord.ButtonStyle.Success)
                );

                const shakeEmojis = ['🌲', '🌳', '🌴', '🎋'];
                const progressBars = ['░░░░░', '▓░░░░', '▓▓░░░', '▓▓▓░░', '▓▓▓▓░', '▓▓▓▓▓'];

                await inter.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`🌳 Shake the Bush! (Round ${currentRound}/${totalRounds})`)
                        .setDescription(`**Keep shaking to find items!**\n\n${shakeEmojis[Math.floor(Math.random() * shakeEmojis.length)]} Progress: ${progressBars[0]}`)
                        .setColor('#27ae60')
                    ],
                    components: [shakeButton()]
                });

                const shakeCollector = interaction.channel.createMessageComponentCollector({
                    filter: i => filter(i) && i.customId === 'forage_shake',
                    time: 10000
                });

                shakeCollector.on('collect', async (shakeInt) => {
                    shakeCount++;
                    const progressIdx = Math.min(Math.floor((shakeCount / requiredShakes) * 5), 5);
                    
                    if (shakeCount >= requiredShakes) {
                        shakeCollector.stop('success');
                        foundItems.push(targetItem);
                        
                        if (currentRound < totalRounds) {
                            await shakeInt.update({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle(`${targetItem.emoji} Found ${targetItem.name}!`)
                                    .setDescription(`Worth $${targetItem.value}!\n\nNext round starting...`)
                                    .setColor('#2ecc71')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging(shakeInt);
                        }
                    } else {
                        await shakeInt.update({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle(`🌳 Shake the Bush! (Round ${currentRound}/${totalRounds})`)
                                .setDescription(`**Keep shaking!**\n\n${shakeEmojis[Math.floor(Math.random() * shakeEmojis.length)]} Progress: ${progressBars[progressIdx]}`)
                                .setColor('#27ae60')
                            ],
                            components: [shakeButton()]
                        });
                    }
                });

                shakeCollector.on('end', async (collected, reason) => {
                    if (reason === 'time') {
                        if (currentRound < totalRounds) {
                            await interaction.editReply({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('⏰ Too Slow!')
                                    .setDescription('Not enough shakes! Next round...')
                                    .setColor('#e74c3c')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging({ update: (opts) => interaction.editReply(opts) });
                        }
                    }
                });

            } else if (game.type === 'memory') {
                const items = [];
                for (let i = 0; i < 3; i++) {
                    items.push(selectItem(selectedArea.items));
                }
                const sequence = items.map(i => i.emoji);
                
                await inter.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`🧠 Memory Hunt! (Round ${currentRound}/${totalRounds})`)
                        .setDescription(`**Remember these items:**\n\n${sequence.join(' → ')}\n\n*Memorize the order!*`)
                        .setColor('#3498db')
                    ],
                    components: []
                });

                await new Promise(r => setTimeout(r, 3000));

                const shuffledItems = shuffle(items);
                const buttons = shuffledItems.map((item, idx) => 
                    new Discord.ButtonBuilder()
                        .setCustomId(`forage_mem_${idx}_${item.emoji}`)
                        .setEmoji(item.emoji)
                        .setStyle(Discord.ButtonStyle.Secondary)
                );

                await interaction.editReply({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`🧠 Memory Hunt! (Round ${currentRound}/${totalRounds})`)
                        .setDescription(`**Click items in the correct order!**\n\nFirst item: ?`)
                        .setColor('#3498db')
                    ],
                    components: [new Discord.ActionRowBuilder().addComponents(buttons)]
                });

                let memoryStep = 0;
                let memorySuccess = true;

                const memCollector = interaction.channel.createMessageComponentCollector({
                    filter: i => filter(i) && i.customId.startsWith('forage_mem_'),
                    time: 15000
                });

                memCollector.on('collect', async (memInt) => {
                    const clickedEmoji = memInt.customId.split('_')[3];
                    
                    if (clickedEmoji === sequence[memoryStep]) {
                        memoryStep++;
                        
                        if (memoryStep >= sequence.length) {
                            memCollector.stop('success');
                            items.forEach(item => foundItems.push(item));
                            
                            if (currentRound < totalRounds) {
                                await memInt.update({
                                    embeds: [new Discord.EmbedBuilder()
                                        .setTitle('✅ Perfect Memory!')
                                        .setDescription(`Found all ${items.length} items!\n\nNext round...`)
                                        .setColor('#2ecc71')
                                    ],
                                    components: []
                                });
                                await new Promise(r => setTimeout(r, 1500));
                                await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                            } else {
                                await finishForaging(memInt);
                            }
                        } else {
                            await memInt.update({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle(`🧠 Memory Hunt! (Round ${currentRound}/${totalRounds})`)
                                    .setDescription(`**Correct!** Next item: ${memoryStep + 1}/${sequence.length}`)
                                    .setColor('#3498db')
                                ],
                                components: [new Discord.ActionRowBuilder().addComponents(buttons)]
                            });
                        }
                    } else {
                        memorySuccess = false;
                        memCollector.stop('fail');
                        
                        if (currentRound < totalRounds) {
                            await memInt.update({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('❌ Wrong Order!')
                                    .setDescription(`The correct order was: ${sequence.join(' → ')}\n\nNext round...`)
                                    .setColor('#e74c3c')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 2000));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging(memInt);
                        }
                    }
                });

                memCollector.on('end', async (collected, reason) => {
                    if (reason === 'time' && memoryStep < sequence.length) {
                        if (currentRound < totalRounds) {
                            await interaction.editReply({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('⏰ Time Up!')
                                    .setDescription('Ran out of time! Next round...')
                                    .setColor('#e74c3c')
                                ],
                                components: []
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await runMiniGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await finishForaging({ update: (opts) => interaction.editReply(opts) });
                        }
                    }
                });
            }
        }

        async function finishForaging(inter) {
            if (foundItems.length === 0) {
                return inter.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle(`${selectedArea.emoji} No Luck Today`)
                        .setDescription(`You searched the ${selectedArea.name.toLowerCase()} but didn't catch anything.\nBetter luck next time!`)
                        .setColor('#e74c3c')
                    ],
                    components: []
                });
            }

            const itemCounts = {};
            let totalValue = 0;
            
            for (const item of foundItems) {
                const key = item.name;
                if (!itemCounts[key]) itemCounts[key] = { ...item, count: 0 };
                itemCounts[key].count++;
                totalValue += item.value;
            }

            const itemList = Object.values(itemCounts)
                .map(i => `${i.emoji} **${i.name}** x${i.count} ($${(i.value * i.count).toLocaleString()})`)
                .join('\n');

            await Schema.findOneAndUpdate(
                { Guild: interaction.guild.id, User: interaction.user.id },
                { $inc: { Money: totalValue } },
                { upsert: true }
            );

            return inter.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`${selectedArea.emoji} Foraging Complete!`)
                    .setDescription(`**Items Found:**\n${itemList}\n\n💰 **Total Earned:** $${totalValue.toLocaleString()}`)
                    .setColor('#2ecc71')
                    .setFooter({ text: `Completed ${totalRounds} mini-games in the ${selectedArea.name.toLowerCase()}` })
                ],
                components: []
            });
        }

        await runMiniGame(areaInteraction);

    } catch (e) {
        return interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('⏰ Timed Out')
                .setDescription('You took too long to choose an area!')
                .setColor('#95a5a6')
            ],
            components: []
        });
    }
};
