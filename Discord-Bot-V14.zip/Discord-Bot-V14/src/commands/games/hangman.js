const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const wordCategories = {
    animals: ['elephant', 'giraffe', 'penguin', 'dolphin', 'kangaroo', 'crocodile', 'butterfly', 'octopus'],
    countries: ['australia', 'brazil', 'canada', 'germany', 'japan', 'mexico', 'sweden', 'thailand'],
    food: ['hamburger', 'spaghetti', 'chocolate', 'pancakes', 'sandwich', 'popcorn', 'broccoli', 'strawberry'],
    movies: ['titanic', 'avatar', 'inception', 'gladiator', 'frozen', 'shrek', 'matrix', 'joker'],
    sports: ['basketball', 'football', 'swimming', 'volleyball', 'baseball', 'tennis', 'hockey', 'cricket']
};

const hangmanStages = [
    '```\n  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n      |\n      |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n  |   |\n      |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n /|   |\n      |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n      |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n /    |\n      |\n=========```',
    '```\n  +---+\n  |   |\n  O   |\n /|\\  |\n / \\  |\n      |\n=========```'
];

module.exports = async (client, interaction, args) => {
    const categories = Object.keys(wordCategories);
    const category = categories[Math.floor(Math.random() * categories.length)];
    const words = wordCategories[category];
    const word = words[Math.floor(Math.random() * words.length)].toLowerCase();
    
    let guessedLetters = [];
    let wrongGuesses = 0;
    const maxWrong = 6;

    function getDisplayWord() {
        return word.split('').map(letter => guessedLetters.includes(letter) ? letter : '_').join(' ');
    }

    function createEmbed() {
        const displayWord = getDisplayWord();
        const isWon = !displayWord.includes('_');
        const isLost = wrongGuesses >= maxWrong;

        let color = '#3498db';
        if (isWon) color = '#2ecc71';
        if (isLost) color = '#e74c3c';

        return new Discord.EmbedBuilder()
            .setTitle('📜 Hangman')
            .setDescription(`${hangmanStages[wrongGuesses]}\n\n**Word:** ${displayWord}\n\n**Category:** ${category.charAt(0).toUpperCase() + category.slice(1)}`)
            .addFields(
                { name: '❌ Wrong', value: `${wrongGuesses}/${maxWrong}`, inline: true },
                { name: '🔤 Guessed', value: guessedLetters.length > 0 ? guessedLetters.join(', ') : 'None', inline: true }
            )
            .setColor(color);
    }

    function createButtons() {
        const rows = [];
        const alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
        
        for (let i = 0; i < 4; i++) {
            const buttons = alphabet.slice(i * 7, (i + 1) * 7).map(letter => 
                new Discord.ButtonBuilder()
                    .setCustomId(`hangman_${letter}`)
                    .setLabel(letter.toUpperCase())
                    .setStyle(guessedLetters.includes(letter) 
                        ? (word.includes(letter) ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Danger)
                        : Discord.ButtonStyle.Secondary)
                    .setDisabled(guessedLetters.includes(letter))
            );
            if (buttons.length > 0) {
                rows.push(new Discord.ActionRowBuilder().addComponents(buttons));
            }
        }
        return rows;
    }

    await interaction.editReply({
        embeds: [createEmbed()],
        components: createButtons()
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('hangman_'),
        time: 120000
    });

    collector.on('collect', async (i) => {
        const letter = i.customId.replace('hangman_', '');
        
        if (guessedLetters.includes(letter)) {
            return i.deferUpdate();
        }

        guessedLetters.push(letter);

        if (!word.includes(letter)) {
            wrongGuesses++;
        }

        const displayWord = getDisplayWord();
        const isWon = !displayWord.includes('_');
        const isLost = wrongGuesses >= maxWrong;

        if (isWon || isLost) {
            collector.stop(isWon ? 'win' : 'lose');

            const reward = isWon ? Math.floor((maxWrong - wrongGuesses + 1) * 50 + word.length * 20) : 0;

            if (reward > 0) {
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: reward } },
                    { upsert: true }
                );
            }

            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(isWon ? '🎉 You Won!' : '💀 Game Over!')
                    .setDescription(`${hangmanStages[wrongGuesses]}\n\n**The word was:** ${word}\n\n${isWon ? `💰 You earned **$${reward}**!` : 'Better luck next time!'}`)
                    .setColor(isWon ? '#2ecc71' : '#e74c3c')
                ],
                components: []
            });
        } else {
            await i.update({
                embeds: [createEmbed()],
                components: createButtons()
            });
        }
    });

    collector.on('end', async (collected, reason) => {
        if (reason === 'time') {
            await interaction.editReply({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('⏰ Time Up!')
                    .setDescription(`The word was: **${word}**`)
                    .setColor('#95a5a6')
                ],
                components: []
            });
        }
    });
};
