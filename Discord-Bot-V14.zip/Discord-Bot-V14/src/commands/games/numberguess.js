const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    const maxNumber = 100;
    const secretNumber = Math.floor(Math.random() * maxNumber) + 1;
    let guesses = 0;
    const maxGuesses = 7;
    let guessHistory = [];

    function createEmbed(message, color, showHistory = true) {
        const embed = new Discord.EmbedBuilder()
            .setTitle('🔢 Number Guess')
            .setDescription(`${message}\n\n**Range:** 1 - ${maxNumber}\n**Guesses Left:** ${maxGuesses - guesses}`)
            .setColor(color);

        if (showHistory && guessHistory.length > 0) {
            embed.addFields({
                name: '📜 Previous Guesses',
                value: guessHistory.slice(-5).map(g => `${g.num} - ${g.result}`).join('\n')
            });
        }

        return embed;
    }

    function createGuessButtons() {
        const rows = [];
        
        const row1 = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder().setCustomId('guess_input').setLabel('🔢 Enter Guess').setStyle(Discord.ButtonStyle.Success),
            new Discord.ButtonBuilder().setCustomId('guess_hint').setLabel('💡 Buy Hint ($50)').setStyle(Discord.ButtonStyle.Secondary)
        );
        rows.push(row1);

        return rows;
    }

    async function startGame() {
        await interaction.editReply({
            embeds: [createEmbed(`I'm thinking of a number between **1** and **${maxNumber}**.\n\nCan you guess it?`, '#3498db', false)],
            components: createGuessButtons()
        });

        const collector = interaction.channel.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id && i.customId.startsWith('guess_'),
            time: 120000
        });

        collector.on('collect', async (i) => {
            if (i.customId === 'guess_hint') {
                const userData = await Schema.findOne({ Guild: interaction.guild.id, User: interaction.user.id });
                
                if (!userData || userData.Money < 50) {
                    return i.reply({ content: 'You need $50 to buy a hint!', ephemeral: true });
                }

                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: -50 } }
                );

                const range = Math.floor(maxNumber / 4);
                const lowerHint = Math.max(1, secretNumber - range);
                const upperHint = Math.min(maxNumber, secretNumber + range);

                return i.reply({ 
                    content: `💡 **Hint purchased!** (-$50)\n\nThe number is between **${lowerHint}** and **${upperHint}**`, 
                    ephemeral: true 
                });
            }

            if (i.customId === 'guess_input') {
                const modal = new Discord.ModalBuilder()
                    .setCustomId('guess_modal')
                    .setTitle('Enter Your Guess');

                const guessInput = new Discord.TextInputBuilder()
                    .setCustomId('guess_number')
                    .setLabel(`Enter a number (1-${maxNumber})`)
                    .setStyle(Discord.TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(3);

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(guessInput));
                await i.showModal(modal);

                try {
                    const modalInt = await i.awaitModalSubmit({
                        filter: m => m.customId === 'guess_modal' && m.user.id === interaction.user.id,
                        time: 30000
                    });

                    const guess = parseInt(modalInt.fields.getTextInputValue('guess_number'));

                    if (isNaN(guess) || guess < 1 || guess > maxNumber) {
                        return modalInt.reply({ content: `Please enter a valid number between 1 and ${maxNumber}!`, ephemeral: true });
                    }

                    guesses++;

                    if (guess === secretNumber) {
                        collector.stop('win');
                        
                        const baseReward = 500;
                        const bonus = Math.floor((maxGuesses - guesses) * 100);
                        const totalReward = baseReward + bonus;

                        await Schema.findOneAndUpdate(
                            { Guild: interaction.guild.id, User: interaction.user.id },
                            { $inc: { Money: totalReward } },
                            { upsert: true }
                        );

                        return modalInt.update({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle('🎉 You Got It!')
                                .setDescription(`The number was **${secretNumber}**!\n\n🎯 Guessed in **${guesses}** tries\n💰 Base Reward: $500\n⭐ Speed Bonus: +$${bonus}\n\n**Total:** $${totalReward.toLocaleString()}`)
                                .setColor('#2ecc71')
                            ],
                            components: []
                        });
                    }

                    if (guess < secretNumber) {
                        guessHistory.push({ num: guess, result: '📈 Too Low' });
                    } else {
                        guessHistory.push({ num: guess, result: '📉 Too High' });
                    }

                    if (guesses >= maxGuesses) {
                        collector.stop('lose');
                        return modalInt.update({
                            embeds: [new Discord.EmbedBuilder()
                                .setTitle('💀 Game Over!')
                                .setDescription(`You ran out of guesses!\n\nThe number was **${secretNumber}**`)
                                .setColor('#e74c3c')
                            ],
                            components: []
                        });
                    }

                    const hint = guess < secretNumber ? '📈 **Too Low!** Go higher!' : '📉 **Too High!** Go lower!';
                    
                    await modalInt.update({
                        embeds: [createEmbed(hint, '#f39c12')],
                        components: createGuessButtons()
                    });

                } catch (err) {
                    // Modal timeout
                }
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                await interaction.editReply({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('⏰ Time Up!')
                        .setDescription(`You took too long!\n\nThe number was **${secretNumber}**`)
                        .setColor('#95a5a6')
                    ],
                    components: []
                });
            }
        });
    }

    await startGame();
};
