const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const colors = [
    { name: 'Red', hex: '#e74c3c', emoji: '🔴' },
    { name: 'Blue', hex: '#3498db', emoji: '🔵' },
    { name: 'Green', hex: '#2ecc71', emoji: '🟢' },
    { name: 'Yellow', hex: '#f1c40f', emoji: '🟡' },
    { name: 'Purple', hex: '#9b59b6', emoji: '🟣' },
    { name: 'Orange', hex: '#e67e22', emoji: '🟠' },
    { name: 'White', hex: '#ecf0f1', emoji: '⚪' },
    { name: 'Black', hex: '#2c3e50', emoji: '⚫' }
];

module.exports = async (client, interaction, args) => {
    let score = 0;
    let round = 0;
    const maxRounds = 5;
    let streak = 0;

    async function playRound(inter) {
        round++;
        const targetColor = colors[Math.floor(Math.random() * colors.length)];
        
        const otherColors = colors.filter(c => c.name !== targetColor.name);
        const shuffled = [...otherColors].sort(() => Math.random() - 0.5);
        const options = [targetColor, ...shuffled.slice(0, 3)].sort(() => Math.random() - 0.5);

        const isTricky = Math.random() < 0.4;
        let displayColor = targetColor;
        let correctAnswer = targetColor.name;
        
        if (isTricky) {
            const fakeColor = colors.filter(c => c.name !== targetColor.name)[Math.floor(Math.random() * (colors.length - 1))];
            displayColor = fakeColor;
        }

        const buttons = options.map(color => 
            new Discord.ButtonBuilder()
                .setCustomId(`color_${color.name}`)
                .setLabel(color.name)
                .setStyle(Discord.ButtonStyle.Secondary)
        );

        await inter.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle(`🎨 Color Guess - Round ${round}/${maxRounds}`)
                .setDescription(isTricky 
                    ? `**What color is the TEXT below?**\n\n(Not the word itself!)` 
                    : `**What color is this?**`)
                .addFields(
                    { name: isTricky ? 'The Word Says:' : 'Color:', value: isTricky ? `\`${displayColor.name}\`` : targetColor.emoji, inline: true },
                    { name: '💰 Score', value: `$${score}`, inline: true },
                    { name: '🔥 Streak', value: `${streak}x`, inline: true }
                )
                .setColor(targetColor.hex)
            ],
            components: [new Discord.ActionRowBuilder().addComponents(buttons)]
        });

        try {
            const colorInt = await interaction.channel.awaitMessageComponent({
                filter: i => i.user.id === interaction.user.id && i.customId.startsWith('color_'),
                time: 10000
            });

            const chosen = colorInt.customId.replace('color_', '');

            if (chosen === correctAnswer) {
                streak++;
                const reward = 50 + (streak * 25) + (isTricky ? 50 : 0);
                score += reward;

                if (round >= maxRounds) {
                    await finishGame(colorInt);
                } else {
                    await colorInt.update({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('✅ Correct!')
                            .setDescription(`+$${reward}${isTricky ? ' (Tricky bonus!)' : ''}\n\nNext round...`)
                            .setColor('#2ecc71')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 1200));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            } else {
                streak = 0;
                if (round >= maxRounds) {
                    await finishGame(colorInt);
                } else {
                    await colorInt.update({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('❌ Wrong!')
                            .setDescription(`The answer was **${correctAnswer}**!\n\nNext round...`)
                            .setColor('#e74c3c')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 1200));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            }
        } catch (e) {
            streak = 0;
            if (round >= maxRounds) {
                await finishGame({ update: (opts) => interaction.editReply(opts) });
            } else {
                await interaction.editReply({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('⏰ Too Slow!')
                        .setDescription('Next round...')
                        .setColor('#95a5a6')
                    ],
                    components: []
                });
                await new Promise(r => setTimeout(r, 1200));
                await playRound({ update: (opts) => interaction.editReply(opts) });
            }
        }
    }

    async function finishGame(inter) {
        if (score > 0) {
            await Schema.findOneAndUpdate(
                { Guild: interaction.guild.id, User: interaction.user.id },
                { $inc: { Money: score } },
                { upsert: true }
            );
        }

        await inter.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('🎨 Color Guess Complete!')
                .setDescription(`You completed ${maxRounds} rounds!\n\n💰 **Total Earned:** $${score.toLocaleString()}`)
                .setColor('#9b59b6')
            ],
            components: []
        });
    }

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('🎨 Color Guess')
            .setDescription('Identify the correct color!\n\n⚠️ Watch out for tricky rounds where the word and color don\'t match!')
            .setColor('#9b59b6')
        ],
        components: [new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('colorguess_start')
                .setLabel('▶️ Start Game')
                .setStyle(Discord.ButtonStyle.Success)
        )]
    });

    try {
        const startInt = await interaction.channel.awaitMessageComponent({
            filter: i => i.user.id === interaction.user.id && i.customId === 'colorguess_start',
            time: 30000
        });
        await playRound(startInt);
    } catch (e) {
        await interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('⏰ Timed Out')
                .setDescription('Game cancelled.')
                .setColor('#95a5a6')
            ],
            components: []
        });
    }
};
