const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    const board = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];
    let currentPlayer = 'X';
    let gameOver = false;

    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];

    function checkWinner(b) {
        for (const pattern of winPatterns) {
            if (b[pattern[0]] === b[pattern[1]] && b[pattern[1]] === b[pattern[2]]) {
                return b[pattern[0]];
            }
        }
        if (!b.some(cell => cell !== 'X' && cell !== 'O')) return 'tie';
        return null;
    }

    function minimax(b, depth, isMaximizing) {
        const winner = checkWinner(b);
        if (winner === 'O') return 10 - depth;
        if (winner === 'X') return depth - 10;
        if (winner === 'tie') return 0;

        if (isMaximizing) {
            let bestScore = -Infinity;
            for (let i = 0; i < 9; i++) {
                if (b[i] !== 'X' && b[i] !== 'O') {
                    const temp = b[i];
                    b[i] = 'O';
                    bestScore = Math.max(bestScore, minimax(b, depth + 1, false));
                    b[i] = temp;
                }
            }
            return bestScore;
        } else {
            let bestScore = Infinity;
            for (let i = 0; i < 9; i++) {
                if (b[i] !== 'X' && b[i] !== 'O') {
                    const temp = b[i];
                    b[i] = 'X';
                    bestScore = Math.min(bestScore, minimax(b, depth + 1, true));
                    b[i] = temp;
                }
            }
            return bestScore;
        }
    }

    function botMove() {
        if (Math.random() < 0.3) {
            const available = board.map((cell, idx) => cell !== 'X' && cell !== 'O' ? idx : null).filter(i => i !== null);
            return available[Math.floor(Math.random() * available.length)];
        }

        let bestScore = -Infinity;
        let bestMove = null;

        for (let i = 0; i < 9; i++) {
            if (board[i] !== 'X' && board[i] !== 'O') {
                const temp = board[i];
                board[i] = 'O';
                const score = minimax(board, 0, false);
                board[i] = temp;
                if (score > bestScore) {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }
        return bestMove;
    }

    function createBoard() {
        const rows = [];
        for (let row = 0; row < 3; row++) {
            const buttons = [];
            for (let col = 0; col < 3; col++) {
                const idx = row * 3 + col;
                const cell = board[idx];
                const btn = new Discord.ButtonBuilder()
                    .setCustomId(`ttt_${idx}`);

                if (cell === 'X') {
                    btn.setEmoji('❌').setStyle(Discord.ButtonStyle.Danger).setDisabled(true);
                } else if (cell === 'O') {
                    btn.setEmoji('⭕').setStyle(Discord.ButtonStyle.Primary).setDisabled(true);
                } else {
                    btn.setLabel(cell).setStyle(Discord.ButtonStyle.Secondary).setDisabled(gameOver);
                }
                buttons.push(btn);
            }
            rows.push(new Discord.ActionRowBuilder().addComponents(buttons));
        }
        return rows;
    }

    function createEmbed(status, color) {
        return new Discord.EmbedBuilder()
            .setTitle('❌⭕ Tic-Tac-Toe')
            .setDescription(`You are **X** | Bot is **O**\n\n${status}`)
            .setColor(color);
    }

    await interaction.editReply({
        embeds: [createEmbed('Your turn! Click a square.', '#3498db')],
        components: createBoard()
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('ttt_'),
        time: 120000
    });

    collector.on('collect', async (i) => {
        const idx = parseInt(i.customId.split('_')[1]);

        if (board[idx] === 'X' || board[idx] === 'O') {
            return i.deferUpdate();
        }

        board[idx] = 'X';

        let winner = checkWinner(board);
        if (winner) {
            gameOver = true;
            collector.stop(winner);

            const reward = winner === 'X' ? 200 : 0;
            if (reward > 0) {
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: reward } },
                    { upsert: true }
                );
            }

            let resultText = '';
            let color = '#95a5a6';
            if (winner === 'X') {
                resultText = '🎉 **You Win!** +$200';
                color = '#2ecc71';
            } else if (winner === 'O') {
                resultText = '💀 **Bot Wins!**';
                color = '#e74c3c';
            } else {
                resultText = "🤝 **It's a tie!**";
            }

            return i.update({
                embeds: [createEmbed(resultText, color)],
                components: createBoard()
            });
        }

        const botIdx = botMove();
        if (botIdx !== null) {
            board[botIdx] = 'O';
        }

        winner = checkWinner(board);
        if (winner) {
            gameOver = true;
            collector.stop(winner);

            let resultText = '';
            let color = '#95a5a6';
            if (winner === 'X') {
                resultText = '🎉 **You Win!** +$200';
                color = '#2ecc71';
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: 200 } },
                    { upsert: true }
                );
            } else if (winner === 'O') {
                resultText = '💀 **Bot Wins!**';
                color = '#e74c3c';
            } else {
                resultText = "🤝 **It's a tie!**";
            }

            return i.update({
                embeds: [createEmbed(resultText, color)],
                components: createBoard()
            });
        }

        await i.update({
            embeds: [createEmbed('Your turn!', '#3498db')],
            components: createBoard()
        });
    });

    collector.on('end', async (collected, reason) => {
        if (reason === 'time') {
            gameOver = true;
            await interaction.editReply({
                embeds: [createEmbed('⏰ Game timed out!', '#95a5a6')],
                components: createBoard()
            });
        }
    });
};
