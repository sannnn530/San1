const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    const bet = args.find(a => a.name === 'amount')?.value || 100;
    const choice = args.find(a => a.name === 'side')?.value || 'heads';

    const userData = await Schema.findOne({ Guild: interaction.guild.id, User: interaction.user.id });
    
    if (!userData || userData.Money < bet) {
        return interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('❌ Not Enough Money')
                .setDescription(`You need $${bet.toLocaleString()} to play!`)
                .setColor('#e74c3c')
            ]
        });
    }

    if (bet < 10) {
        return interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('❌ Minimum Bet')
                .setDescription('Minimum bet is $10!')
                .setColor('#e74c3c')
            ]
        });
    }

    if (bet > 50000) {
        return interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('❌ Maximum Bet')
                .setDescription('Maximum bet is $50,000!')
                .setColor('#e74c3c')
            ]
        });
    }

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('🪙 Flipping...')
            .setDescription('The coin is in the air!')
            .setColor('#f39c12')
        ]
    });

    await new Promise(r => setTimeout(r, 1500));

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = choice === result;
    const winnings = won ? bet : -bet;

    await Schema.findOneAndUpdate(
        { Guild: interaction.guild.id, User: interaction.user.id },
        { $inc: { Money: winnings } }
    );

    const coinEmoji = result === 'heads' ? '🟡' : '⚪';

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle(`${coinEmoji} ${result.toUpperCase()}!`)
            .setDescription(won 
                ? `You chose **${choice}** and won **$${bet.toLocaleString()}**!` 
                : `You chose **${choice}** and lost **$${bet.toLocaleString()}**!`)
            .setColor(won ? '#2ecc71' : '#e74c3c')
        ],
        components: [new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId(`coinflip_again_${bet}_${choice}`)
                .setLabel('🔄 Play Again')
                .setStyle(Discord.ButtonStyle.Primary)
        )]
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('coinflip_again_'),
        time: 30000,
        max: 1
    });

    collector.on('collect', async (i) => {
        const parts = i.customId.split('_');
        const newBet = parseInt(parts[2]);
        const newChoice = parts[3];

        const newData = await Schema.findOne({ Guild: interaction.guild.id, User: interaction.user.id });
        
        if (!newData || newData.Money < newBet) {
            return i.reply({ content: 'Not enough money to play again!', ephemeral: true });
        }

        await i.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('🪙 Flipping...')
                .setDescription('The coin is in the air!')
                .setColor('#f39c12')
            ],
            components: []
        });

        await new Promise(r => setTimeout(r, 1500));

        const newResult = Math.random() < 0.5 ? 'heads' : 'tails';
        const newWon = newChoice === newResult;
        const newWinnings = newWon ? newBet : -newBet;

        await Schema.findOneAndUpdate(
            { Guild: interaction.guild.id, User: interaction.user.id },
            { $inc: { Money: newWinnings } }
        );

        const newCoinEmoji = newResult === 'heads' ? '🟡' : '⚪';

        await interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle(`${newCoinEmoji} ${newResult.toUpperCase()}!`)
                .setDescription(newWon 
                    ? `You chose **${newChoice}** and won **$${newBet.toLocaleString()}**!` 
                    : `You chose **${newChoice}** and lost **$${newBet.toLocaleString()}**!`)
                .setColor(newWon ? '#2ecc71' : '#e74c3c')
            ]
        });
    });
};
