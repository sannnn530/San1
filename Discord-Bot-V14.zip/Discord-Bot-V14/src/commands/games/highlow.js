const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    let score = 0;
    let streak = 0;
    let currentNumber = Math.floor(Math.random() * 100) + 1;
    let round = 0;
    const maxRounds = 10;

    function createEmbed(message, showResult = false, wasCorrect = false) {
        return new Discord.EmbedBuilder()
            .setTitle('📊 High or Low?')
            .setDescription(`${message}\n\n# ${currentNumber}`)
            .addFields(
                { name: '💰 Score', value: `$${score}`, inline: true },
                { name: '🔥 Streak', value: `${streak}x`, inline: true },
                { name: '📊 Round', value: `${round}/${maxRounds}`, inline: true }
            )
            .setColor(showResult ? (wasCorrect ? '#2ecc71' : '#e74c3c') : '#3498db')
            .setFooter({ text: 'Will the next number be higher or lower?' });
    }

    function createButtons(disabled = false) {
        return new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('highlow_high')
                .setLabel('📈 Higher')
                .setStyle(Discord.ButtonStyle.Success)
                .setDisabled(disabled),
            new Discord.ButtonBuilder()
                .setCustomId('highlow_low')
                .setLabel('📉 Lower')
                .setStyle(Discord.ButtonStyle.Danger)
                .setDisabled(disabled),
            new Discord.ButtonBuilder()
                .setCustomId('highlow_cashout')
                .setLabel(`💰 Cash Out ($${score})`)
                .setStyle(Discord.ButtonStyle.Secondary)
                .setDisabled(disabled || score === 0)
        );
    }

    await interaction.editReply({
        embeds: [createEmbed('**Will the next number be higher or lower?**')],
        components: [createButtons()]
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('highlow_'),
        time: 120000
    });

    collector.on('collect', async (i) => {
        if (i.customId === 'highlow_cashout') {
            collector.stop('cashout');

            if (score > 0) {
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: score } },
                    { upsert: true }
                );
            }

            return i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('💰 Cashed Out!')
                    .setDescription(`You walked away with **$${score.toLocaleString()}**!\n\n🔥 Best streak: ${streak}x`)
                    .setColor('#f39c12')
                ],
                components: []
            });
        }

        const guess = i.customId === 'highlow_high' ? 'high' : 'low';
        const oldNumber = currentNumber;
        let newNumber;
        
        do {
            newNumber = Math.floor(Math.random() * 100) + 1;
        } while (newNumber === oldNumber);

        currentNumber = newNumber;
        round++;

        const isHigher = newNumber > oldNumber;
        const correct = (guess === 'high' && isHigher) || (guess === 'low' && !isHigher);

        if (correct) {
            streak++;
            const reward = 25 + (streak * 15);
            score += reward;

            if (round >= maxRounds) {
                collector.stop('win');

                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: score } },
                    { upsert: true }
                );

                return i.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('🎉 Perfect Game!')
                        .setDescription(`You completed all ${maxRounds} rounds!\n\n💰 **Total Earned:** $${score.toLocaleString()}\n🔥 **Final Streak:** ${streak}x`)
                        .setColor('#2ecc71')
                    ],
                    components: []
                });
            }

            await i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`✅ Correct! ${oldNumber} → ${newNumber}`)
                    .setDescription(`**+$${reward}** (Streak: ${streak}x)\n\n# ${currentNumber}\n\n**Will the next number be higher or lower?**`)
                    .addFields(
                        { name: '💰 Score', value: `$${score}`, inline: true },
                        { name: '🔥 Streak', value: `${streak}x`, inline: true },
                        { name: '📊 Round', value: `${round}/${maxRounds}`, inline: true }
                    )
                    .setColor('#2ecc71')
                ],
                components: [createButtons()]
            });
        } else {
            collector.stop('lose');

            const lostAmount = Math.floor(score * 0.5);
            const savedAmount = score - lostAmount;

            if (savedAmount > 0) {
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: savedAmount } },
                    { upsert: true }
                );
            }

            return i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`❌ Wrong! ${oldNumber} → ${newNumber}`)
                    .setDescription(`You guessed **${guess}er** but it went **${isHigher ? 'higher' : 'lower'}**!\n\n💸 Lost half your score!\n💰 **Saved:** $${savedAmount}`)
                    .setColor('#e74c3c')
                ],
                components: []
            });
        }
    });

    collector.on('end', async (collected, reason) => {
        if (reason === 'time') {
            if (score > 0) {
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: score } },
                    { upsert: true }
                );
            }

            await interaction.editReply({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('⏰ Time Up!')
                    .setDescription(`Game ended!\n\n💰 **Saved:** $${score}`)
                    .setColor('#95a5a6')
                ],
                components: []
            });
        }
    });
};
