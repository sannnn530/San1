const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

module.exports = async (client, interaction, args) => {
    let totalReward = 0;
    let round = 0;
    const maxRounds = 5;
    const reactionTimes = [];

    const targetEmojis = ['🎯', '⭐', '💎', '🔥', '⚡', '🌟', '💫', '✨'];
    const decoyEmojis = ['⬜', '⬛', '🔲', '🔳', '◻️', '◼️', '▪️', '▫️'];

    async function playRound(inter) {
        round++;
        const targetEmoji = targetEmojis[Math.floor(Math.random() * targetEmojis.length)];
        
        await inter.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle(`⚡ Reaction Race - Round ${round}/${maxRounds}`)
                .setDescription(`**Get Ready!**\n\nClick the ${targetEmoji} as fast as you can when it appears!\n\n⏳ Starting in 3...`)
                .setColor('#3498db')
            ],
            components: []
        });

        const delay = 1500 + Math.random() * 3000;
        await new Promise(r => setTimeout(r, delay));

        const gridSize = 9;
        const targetPos = Math.floor(Math.random() * gridSize);
        const buttons = [];

        for (let i = 0; i < gridSize; i++) {
            buttons.push(
                new Discord.ButtonBuilder()
                    .setCustomId(`react_${i}`)
                    .setEmoji(i === targetPos ? targetEmoji : decoyEmojis[Math.floor(Math.random() * decoyEmojis.length)])
                    .setStyle(i === targetPos ? Discord.ButtonStyle.Success : Discord.ButtonStyle.Secondary)
            );
        }

        const rows = [
            new Discord.ActionRowBuilder().addComponents(buttons.slice(0, 3)),
            new Discord.ActionRowBuilder().addComponents(buttons.slice(3, 6)),
            new Discord.ActionRowBuilder().addComponents(buttons.slice(6, 9))
        ];

        const startTime = Date.now();

        await interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle(`⚡ CLICK THE ${targetEmoji} NOW!`)
                .setDescription(`Round ${round}/${maxRounds}`)
                .setColor('#e74c3c')
            ],
            components: rows
        });

        try {
            const clickInt = await interaction.channel.awaitMessageComponent({
                filter: i => i.user.id === interaction.user.id && i.customId.startsWith('react_'),
                time: 5000
            });

            const reactionTime = Date.now() - startTime;
            const clicked = parseInt(clickInt.customId.split('_')[1]);

            if (clicked === targetPos) {
                reactionTimes.push(reactionTime);
                
                let reward = 0;
                let speedRating = '';
                
                if (reactionTime < 300) {
                    reward = 200;
                    speedRating = '🏆 INSANE!';
                } else if (reactionTime < 500) {
                    reward = 150;
                    speedRating = '⚡ Lightning Fast!';
                } else if (reactionTime < 800) {
                    reward = 100;
                    speedRating = '🔥 Fast!';
                } else if (reactionTime < 1200) {
                    reward = 75;
                    speedRating = '👍 Good';
                } else {
                    reward = 50;
                    speedRating = '🐢 Slow';
                }

                totalReward += reward;

                if (round >= maxRounds) {
                    await finishGame(clickInt);
                } else {
                    await clickInt.update({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle(`${speedRating}`)
                            .setDescription(`⏱️ **${reactionTime}ms**\n💰 +$${reward}\n\nNext round...`)
                            .setColor('#2ecc71')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 1500));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            } else {
                if (round >= maxRounds) {
                    await finishGame(clickInt);
                } else {
                    await clickInt.update({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('❌ Wrong Target!')
                            .setDescription(`You clicked the wrong button!\n\nNext round...`)
                            .setColor('#e74c3c')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 1500));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            }
        } catch (e) {
            if (round >= maxRounds) {
                await finishGame({ update: (opts) => interaction.editReply(opts) });
            } else {
                await interaction.editReply({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('⏰ Too Slow!')
                        .setDescription('You missed it!\n\nNext round...')
                        .setColor('#e74c3c')
                    ],
                    components: []
                });
                await new Promise(r => setTimeout(r, 1500));
                await playRound({ update: (opts) => interaction.editReply(opts) });
            }
        }
    }

    async function finishGame(inter) {
        if (totalReward > 0) {
            await Schema.findOneAndUpdate(
                { Guild: interaction.guild.id, User: interaction.user.id },
                { $inc: { Money: totalReward } },
                { upsert: true }
            );
        }

        const avgTime = reactionTimes.length > 0 
            ? Math.floor(reactionTimes.reduce((a, b) => a + b, 0) / reactionTimes.length)
            : 0;

        const bestTime = reactionTimes.length > 0 ? Math.min(...reactionTimes) : 0;

        await inter.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('⚡ Reaction Race Complete!')
                .setDescription(`**Results:**\n\n⏱️ Best Time: **${bestTime}ms**\n📊 Average: **${avgTime}ms**\n✅ Hits: **${reactionTimes.length}/${maxRounds}**\n\n💰 **Total Earned:** $${totalReward.toLocaleString()}`)
                .setColor('#9b59b6')
            ],
            components: []
        });
    }

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('⚡ Reaction Race')
            .setDescription('Test your reaction speed!\n\n- Click the highlighted target as fast as you can\n- Faster reactions = more money\n- 5 rounds total')
            .addFields(
                { name: '🏆 Insane', value: '<300ms = $200', inline: true },
                { name: '⚡ Fast', value: '<500ms = $150', inline: true },
                { name: '🔥 Good', value: '<800ms = $100', inline: true }
            )
            .setColor('#3498db')
        ],
        components: [new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('reaction_start')
                .setLabel('▶️ Start Game')
                .setStyle(Discord.ButtonStyle.Success)
        )]
    });

    try {
        const startInt = await interaction.channel.awaitMessageComponent({
            filter: i => i.user.id === interaction.user.id && i.customId === 'reaction_start',
            time: 30000
        });
        await playRound(startInt);
    } catch (e) {
        await interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('⏰ Timed Out')
                .setDescription('Game cancelled.')
                .setColor('#95a5a6')
            ],
            components: []
        });
    }
};
