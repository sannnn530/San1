const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const wordLists = {
    easy: [
        { word: 'fish', hint: 'Lives in water', reward: 50 },
        { word: 'boat', hint: 'Floats on water', reward: 50 },
        { word: 'tree', hint: 'Has leaves', reward: 50 },
        { word: 'bird', hint: 'Has wings', reward: 50 },
        { word: 'cake', hint: 'Birthday treat', reward: 50 },
        { word: 'star', hint: 'Shines at night', reward: 50 },
        { word: 'moon', hint: 'Lights up the night', reward: 50 },
        { word: 'frog', hint: 'Says ribbit', reward: 50 }
    ],
    medium: [
        { word: 'dragon', hint: 'Breathes fire', reward: 100 },
        { word: 'wizard', hint: 'Casts spells', reward: 100 },
        { word: 'pirate', hint: 'Sails the seas', reward: 100 },
        { word: 'castle', hint: 'Kings live here', reward: 100 },
        { word: 'rocket', hint: 'Goes to space', reward: 100 },
        { word: 'jungle', hint: 'Dense forest', reward: 100 },
        { word: 'treasure', hint: 'Gold and gems', reward: 150 },
        { word: 'diamond', hint: 'Precious gem', reward: 150 }
    ],
    hard: [
        { word: 'mysterious', hint: 'Hard to explain', reward: 250 },
        { word: 'adventure', hint: 'Exciting journey', reward: 250 },
        { word: 'electricity', hint: 'Powers devices', reward: 300 },
        { word: 'revolution', hint: 'Major change', reward: 300 },
        { word: 'imagination', hint: 'Creative thinking', reward: 350 },
        { word: 'celebration', hint: 'Party time', reward: 350 }
    ]
};

function scrambleWord(word) {
    const arr = word.split('');
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    const scrambled = arr.join('');
    return scrambled === word ? scrambleWord(word) : scrambled;
}

module.exports = async (client, interaction, args) => {
    const difficulties = ['easy', 'medium', 'hard'];
    let currentDifficulty = 'easy';
    let score = 0;
    let round = 0;
    let streak = 0;
    const maxRounds = 5;

    function getWord() {
        const list = wordLists[currentDifficulty];
        return list[Math.floor(Math.random() * list.length)];
    }

    function createGameEmbed(wordData, scrambled, showHint = false) {
        const embed = new Discord.EmbedBuilder()
            .setTitle(`🔤 Word Scramble - Round ${round + 1}/${maxRounds}`)
            .setDescription(`**Unscramble this word:**\n\n# ${scrambled.toUpperCase().split('').join(' ')}`)
            .addFields(
                { name: '💰 Score', value: `$${score.toLocaleString()}`, inline: true },
                { name: '🔥 Streak', value: `${streak}x`, inline: true },
                { name: '📊 Difficulty', value: currentDifficulty.charAt(0).toUpperCase() + currentDifficulty.slice(1), inline: true }
            )
            .setColor(currentDifficulty === 'easy' ? '#2ecc71' : currentDifficulty === 'medium' ? '#f39c12' : '#e74c3c')
            .setFooter({ text: showHint ? `💡 Hint: ${wordData.hint}` : 'Click "Hint" for a clue (reduces reward)' });
        return embed;
    }

    function createButtons(showHint = false) {
        return new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('scramble_answer')
                .setLabel('📝 Answer')
                .setStyle(Discord.ButtonStyle.Success),
            new Discord.ButtonBuilder()
                .setCustomId('scramble_hint')
                .setLabel('💡 Hint')
                .setStyle(Discord.ButtonStyle.Secondary)
                .setDisabled(showHint),
            new Discord.ButtonBuilder()
                .setCustomId('scramble_skip')
                .setLabel('⏭️ Skip')
                .setStyle(Discord.ButtonStyle.Danger)
        );
    }

    async function playRound(inter) {
        const wordData = getWord();
        const scrambled = scrambleWord(wordData.word);
        let hintUsed = false;

        await inter.update({
            embeds: [createGameEmbed(wordData, scrambled, false)],
            components: [createButtons(false)]
        });

        const collector = interaction.channel.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id && i.customId.startsWith('scramble_'),
            time: 30000
        });

        collector.on('collect', async (i) => {
            if (i.customId === 'scramble_hint') {
                hintUsed = true;
                await i.update({
                    embeds: [createGameEmbed(wordData, scrambled, true)],
                    components: [createButtons(true)]
                });
            }

            if (i.customId === 'scramble_skip') {
                collector.stop('skip');
                streak = 0;
                round++;

                if (round >= maxRounds) {
                    await finishGame(i);
                } else {
                    if (round === 2) currentDifficulty = 'medium';
                    if (round === 4) currentDifficulty = 'hard';
                    await i.update({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('⏭️ Skipped!')
                            .setDescription(`The word was: **${wordData.word}**\n\nNext round...`)
                            .setColor('#95a5a6')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 2000));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            }

            if (i.customId === 'scramble_answer') {
                collector.stop('answering');

                const modal = new Discord.ModalBuilder()
                    .setCustomId('scramble_modal')
                    .setTitle('Enter Your Answer');

                const answerInput = new Discord.TextInputBuilder()
                    .setCustomId('scramble_input')
                    .setLabel('What is the word?')
                    .setStyle(Discord.TextInputStyle.Short)
                    .setRequired(true)
                    .setMaxLength(20);

                modal.addComponents(new Discord.ActionRowBuilder().addComponents(answerInput));

                await i.showModal(modal);

                try {
                    const modalInt = await i.awaitModalSubmit({
                        filter: m => m.customId === 'scramble_modal' && m.user.id === interaction.user.id,
                        time: 30000
                    });

                    const answer = modalInt.fields.getTextInputValue('scramble_input').toLowerCase().trim();

                    if (answer === wordData.word.toLowerCase()) {
                        streak++;
                        const reward = Math.floor(wordData.reward * (hintUsed ? 0.5 : 1) * (1 + streak * 0.1));
                        score += reward;
                        round++;

                        if (round >= maxRounds) {
                            await finishGame(modalInt);
                        } else {
                            if (round === 2) currentDifficulty = 'medium';
                            if (round === 4) currentDifficulty = 'hard';

                            await modalInt.reply({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('✅ Correct!')
                                    .setDescription(`**${wordData.word}** is right!\n\n💰 +$${reward.toLocaleString()} ${streak > 1 ? `(${streak}x streak bonus!)` : ''}\n\nNext round starting...`)
                                    .setColor('#2ecc71')
                                ],
                                ephemeral: true
                            });
                            await new Promise(r => setTimeout(r, 1500));
                            await playRound({ update: (opts) => interaction.editReply(opts) });
                        }
                    } else {
                        streak = 0;
                        round++;

                        if (round >= maxRounds) {
                            await modalInt.reply({ content: `Wrong! The word was **${wordData.word}**`, ephemeral: true });
                            await finishGame({ update: (opts) => interaction.editReply(opts) });
                        } else {
                            await modalInt.reply({
                                embeds: [new Discord.EmbedBuilder()
                                    .setTitle('❌ Wrong!')
                                    .setDescription(`The word was: **${wordData.word}**\n\nNext round...`)
                                    .setColor('#e74c3c')
                                ],
                                ephemeral: true
                            });
                            if (round === 2) currentDifficulty = 'medium';
                            if (round === 4) currentDifficulty = 'hard';
                            await new Promise(r => setTimeout(r, 1500));
                            await playRound({ update: (opts) => interaction.editReply(opts) });
                        }
                    }
                } catch (err) {
                    round++;
                    if (round >= maxRounds) {
                        await finishGame({ update: (opts) => interaction.editReply(opts) });
                    } else {
                        await playRound({ update: (opts) => interaction.editReply(opts) });
                    }
                }
            }
        });

        collector.on('end', async (collected, reason) => {
            if (reason === 'time') {
                streak = 0;
                round++;
                if (round >= maxRounds) {
                    await finishGame({ update: (opts) => interaction.editReply(opts) });
                } else {
                    await interaction.editReply({
                        embeds: [new Discord.EmbedBuilder()
                            .setTitle('⏰ Time Up!')
                            .setDescription(`The word was: **${wordData.word}**\n\nNext round...`)
                            .setColor('#95a5a6')
                        ],
                        components: []
                    });
                    await new Promise(r => setTimeout(r, 2000));
                    await playRound({ update: (opts) => interaction.editReply(opts) });
                }
            }
        });
    }

    async function finishGame(inter) {
        if (score > 0) {
            await Schema.findOneAndUpdate(
                { Guild: interaction.guild.id, User: interaction.user.id },
                { $inc: { Money: score } },
                { upsert: true }
            );
        }

        await inter.update({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('🔤 Word Scramble Complete!')
                .setDescription(`You completed ${maxRounds} rounds!\n\n💰 **Total Earned:** $${score.toLocaleString()}`)
                .setColor('#9b59b6')
            ],
            components: []
        });
    }

    await interaction.editReply({
        embeds: [new Discord.EmbedBuilder()
            .setTitle('🔤 Word Scramble')
            .setDescription('Unscramble words to earn money!\n\n- Difficulty increases each round\n- Hints reduce your reward by 50%\n- Streak bonuses for consecutive correct answers!')
            .setColor('#9b59b6')
        ],
        components: [new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
                .setCustomId('scramble_start')
                .setLabel('▶️ Start Game')
                .setStyle(Discord.ButtonStyle.Success)
        )]
    });

    try {
        const startInt = await interaction.channel.awaitMessageComponent({
            filter: i => i.user.id === interaction.user.id && i.customId === 'scramble_start',
            time: 30000
        });
        await playRound(startInt);
    } catch (e) {
        await interaction.editReply({
            embeds: [new Discord.EmbedBuilder()
                .setTitle('⏰ Timed Out')
                .setDescription('Game cancelled.')
                .setColor('#95a5a6')
            ],
            components: []
        });
    }
};
