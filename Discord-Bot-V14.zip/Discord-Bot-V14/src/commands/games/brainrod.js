const Discord = require('discord.js');
const Schema = require("../../database/models/economy");

const puzzleTypes = [
    {
        type: 'math',
        generate: () => {
            const ops = ['+', '-', '*'];
            const op = ops[Math.floor(Math.random() * ops.length)];
            let a, b, answer;
            if (op === '*') {
                a = Math.floor(Math.random() * 12) + 1;
                b = Math.floor(Math.random() * 12) + 1;
                answer = a * b;
            } else if (op === '+') {
                a = Math.floor(Math.random() * 100) + 1;
                b = Math.floor(Math.random() * 100) + 1;
                answer = a + b;
            } else {
                a = Math.floor(Math.random() * 100) + 50;
                b = Math.floor(Math.random() * 50) + 1;
                answer = a - b;
            }
            return { question: `What is ${a} ${op} ${b}?`, answer: answer.toString(), hint: `The answer is a number` };
        }
    },
    {
        type: 'sequence',
        generate: () => {
            const sequences = [
                { seq: [2, 4, 6, 8], next: 10, hint: 'Add 2 each time' },
                { seq: [1, 3, 5, 7], next: 9, hint: 'Odd numbers' },
                { seq: [3, 6, 9, 12], next: 15, hint: 'Multiply by 3' },
                { seq: [1, 2, 4, 8], next: 16, hint: 'Double each time' },
                { seq: [1, 1, 2, 3, 5], next: 8, hint: 'Add previous two' },
                { seq: [100, 90, 80, 70], next: 60, hint: 'Subtract 10' },
                { seq: [5, 10, 20, 40], next: 80, hint: 'Double each time' }
            ];
            const s = sequences[Math.floor(Math.random() * sequences.length)];
            return { question: `What comes next? ${s.seq.join(', ')}, ?`, answer: s.next.toString(), hint: s.hint };
        }
    },
    {
        type: 'emoji',
        generate: () => {
            const puzzles = [
                { q: '🍎 + 🍎 = 10, 🍎 + 🍌 = 12, 🍌 = ?', a: '7', h: 'Apple = 5' },
                { q: '🐱 + 🐱 + 🐱 = 15, 🐱 = ?', a: '5', h: 'Divide by 3' },
                { q: '⭐ × ⭐ = 16, ⭐ = ?', a: '4', h: 'Square root of 16' },
                { q: '🎮 + 🎮 = 20, 🎮 - 5 = ?', a: '5', h: 'Controller = 10' },
                { q: '🍕 ÷ 2 = 4, 🍕 = ?', a: '8', h: 'Multiply by 2' },
                { q: '🚗 + 🚗 + 🚗 = 30, 🚗 + 🚗 = ?', a: '20', h: 'Car = 10' }
            ];
            const p = puzzles[Math.floor(Math.random() * puzzles.length)];
            return { question: p.q, answer: p.a, hint: p.h };
        }
    },
    {
        type: 'word',
        generate: () => {
            const puzzles = [
                { q: 'Unscramble: HSFI', a: 'fish', h: '4 letters, lives in water' },
                { q: 'Unscramble: NOYME', a: 'money', h: '5 letters, you earn this' },
                { q: 'Unscramble: MAEG', a: 'game', h: '4 letters, you play this' },
                { q: 'Unscramble: TOBR', a: 'robot', h: '5 letters, made of metal' },
                { q: 'Unscramble: DRISOC', a: 'discord', h: '7 letters, chat platform' },
                { q: 'Unscramble: ZENOB', a: 'bronze', h: '6 letters, a metal' }
            ];
            const p = puzzles[Math.floor(Math.random() * puzzles.length)];
            return { question: p.q, answer: p.a, hint: p.h };
        }
    }
];

module.exports = async (client, interaction, args) => {
    let score = 0;
    let round = 0;
    const maxRounds = 5;
    let hintUsed = false;
    let currentPuzzle = null;
    let streak = 0;

    const generatePuzzle = () => {
        const puzzleType = puzzleTypes[Math.floor(Math.random() * puzzleTypes.length)];
        return puzzleType.generate();
    };

    const updateEmbed = (puzzle, status, color) => {
        return new Discord.EmbedBuilder()
            .setTitle(`🧠 Brain Rod - Round ${round + 1}/${maxRounds}`)
            .setDescription(`**Puzzle:**\n${puzzle.question}`)
            .addFields(
                { name: '💰 Score', value: `$${score.toLocaleString()}`, inline: true },
                { name: '🔥 Streak', value: `${streak}x`, inline: true },
                { name: '📊 Progress', value: `${round}/${maxRounds}`, inline: true }
            )
            .setColor(color)
            .setFooter({ text: status });
    };

    const answerButtons = (puzzle) => {
        const correctAnswer = puzzle.answer;
        let options = [correctAnswer];
        
        if (!isNaN(correctAnswer)) {
            const num = parseInt(correctAnswer);
            options.push((num + Math.floor(Math.random() * 5) + 1).toString());
            options.push((num - Math.floor(Math.random() * 5) - 1).toString());
            options.push((num + Math.floor(Math.random() * 10) + 5).toString());
        } else {
            const fakes = ['apple', 'water', 'robot', 'dance', 'light', 'stone', 'happy'];
            while (options.length < 4) {
                const fake = fakes[Math.floor(Math.random() * fakes.length)];
                if (!options.includes(fake) && fake !== correctAnswer) options.push(fake);
            }
        }
        
        options = options.sort(() => Math.random() - 0.5).slice(0, 4);
        
        const buttons = options.map(opt => 
            new Discord.ButtonBuilder()
                .setCustomId(`brain_${opt}`)
                .setLabel(opt)
                .setStyle(Discord.ButtonStyle.Primary)
        );
        
        const hintButton = new Discord.ButtonBuilder()
            .setCustomId('brain_hint')
            .setLabel('💡 Hint')
            .setStyle(Discord.ButtonStyle.Secondary)
            .setDisabled(hintUsed);
        
        return [
            new Discord.ActionRowBuilder().addComponents(buttons),
            new Discord.ActionRowBuilder().addComponents(hintButton)
        ];
    };

    currentPuzzle = generatePuzzle();
    
    await interaction.editReply({
        embeds: [updateEmbed(currentPuzzle, 'Choose the correct answer!', '#3498db')],
        components: answerButtons(currentPuzzle)
    });

    const collector = interaction.channel.createMessageComponentCollector({
        filter: i => i.user.id === interaction.user.id && i.customId.startsWith('brain_'),
        time: 120000
    });

    collector.on('collect', async (i) => {
        if (i.customId === 'brain_hint') {
            hintUsed = true;
            return i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`🧠 Brain Rod - Round ${round + 1}/${maxRounds}`)
                    .setDescription(`**Puzzle:**\n${currentPuzzle.question}\n\n💡 **Hint:** ${currentPuzzle.hint}`)
                    .addFields(
                        { name: '💰 Score', value: `$${score.toLocaleString()}`, inline: true },
                        { name: '🔥 Streak', value: `${streak}x`, inline: true },
                        { name: '📊 Progress', value: `${round}/${maxRounds}`, inline: true }
                    )
                    .setColor('#f39c12')
                    .setFooter({ text: 'Hint used! No bonus for this round.' })
                ],
                components: answerButtons(currentPuzzle)
            });
        }

        const answer = i.customId.replace('brain_', '');
        const correct = answer.toLowerCase() === currentPuzzle.answer.toLowerCase();

        if (correct) {
            streak++;
            const baseReward = 50;
            const streakBonus = streak * 25;
            const hintPenalty = hintUsed ? 0.5 : 1;
            const roundReward = Math.floor((baseReward + streakBonus) * hintPenalty);
            score += roundReward;
            round++;
            hintUsed = false;

            if (round >= maxRounds) {
                collector.stop('complete');
                
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: score } },
                    { upsert: true }
                );

                return i.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('🧠 Brain Rod Complete!')
                        .setDescription(`🎉 **Congratulations!**\n\nYou completed all ${maxRounds} puzzles!\n\n💰 **Total Earned:** $${score.toLocaleString()}\n🔥 **Best Streak:** ${streak}x`)
                        .setColor('#2ecc71')
                    ],
                    components: []
                });
            }

            currentPuzzle = generatePuzzle();
            
            return i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`✅ Correct! +$${roundReward}`)
                    .setDescription(`**Next Puzzle:**\n${currentPuzzle.question}`)
                    .addFields(
                        { name: '💰 Score', value: `$${score.toLocaleString()}`, inline: true },
                        { name: '🔥 Streak', value: `${streak}x`, inline: true },
                        { name: '📊 Progress', value: `${round}/${maxRounds}`, inline: true }
                    )
                    .setColor('#2ecc71')
                    .setFooter({ text: 'Keep going!' })
                ],
                components: answerButtons(currentPuzzle)
            });

        } else {
            const correctAnswer = currentPuzzle.answer;
            streak = 0;
            round++;
            hintUsed = false;

            if (round >= maxRounds) {
                collector.stop('complete');
                
                await Schema.findOneAndUpdate(
                    { Guild: interaction.guild.id, User: interaction.user.id },
                    { $inc: { Money: score } },
                    { upsert: true }
                );

                return i.update({
                    embeds: [new Discord.EmbedBuilder()
                        .setTitle('🧠 Brain Rod Complete!')
                        .setDescription(`The answer was: **${correctAnswer}**\n\nYou completed ${maxRounds} puzzles!\n\n💰 **Total Earned:** $${score.toLocaleString()}`)
                        .setColor('#f39c12')
                    ],
                    components: []
                });
            }

            currentPuzzle = generatePuzzle();
            
            return i.update({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle(`❌ Wrong! The answer was: ${correctAnswer}`)
                    .setDescription(`**Next Puzzle:**\n${currentPuzzle.question}`)
                    .addFields(
                        { name: '💰 Score', value: `$${score.toLocaleString()}`, inline: true },
                        { name: '🔥 Streak', value: `${streak}x (reset)`, inline: true },
                        { name: '📊 Progress', value: `${round}/${maxRounds}`, inline: true }
                    )
                    .setColor('#e74c3c')
                    .setFooter({ text: 'Try the next one!' })
                ],
                components: answerButtons(currentPuzzle)
            });
        }
    });

    collector.on('end', (collected, reason) => {
        if (reason === 'time') {
            interaction.editReply({
                embeds: [new Discord.EmbedBuilder()
                    .setTitle('⏰ Time\'s Up!')
                    .setDescription(`You earned **$${score.toLocaleString()}** before timing out.`)
                    .setColor('#95a5a6')
                ],
                components: []
            }).catch(() => {});
        }
    });
};
