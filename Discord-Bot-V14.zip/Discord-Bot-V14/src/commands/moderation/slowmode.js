const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ManageChannels],
        perms: [Discord.PermissionsBitField.Flags.ManageChannels]
    }, interaction);

    if (perms == false) return;

    const seconds = interaction.options.getNumber('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    if (seconds < 0 || seconds > 21600) {
        return client.errNormal({ error: 'Slowmode must be between 0 and 21600 seconds (6 hours)!', type: 'editreply' }, interaction);
    }

    await channel.setRateLimitPerUser(seconds);

    if (seconds === 0) {
        client.succNormal({
            text: `Slowmode has been disabled in ${channel}`,
            type: 'editreply'
        }, interaction);
    } else {
        client.succNormal({
            text: `Slowmode set to **${seconds} seconds** in ${channel}`,
            type: 'editreply'
        }, interaction);
    }
};
