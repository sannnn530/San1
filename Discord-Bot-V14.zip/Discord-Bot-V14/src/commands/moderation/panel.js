const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    name: 'panel',
    description: 'Open the moderation panel in Discord',
    options: [],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has('Administrator')) {
            return interaction.editReply({ content: 'You need Administrator permission to use this command.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('Moderation Panel')
            .setDescription('Select an action below to moderate your server.')
            .setColor('#00d4ff')
            .addFields(
                { name: 'Quick Actions', value: 'Use the buttons below for common moderation tasks.' },
                { name: 'Web Dashboard', value: `[Open Full Panel](${process.env.REPLIT_DEV_DOMAIN ? 'https://' + process.env.REPLIT_DEV_DOMAIN : 'http://localhost:5000'}/panel/${interaction.guild.id})` }
            )
            .setFooter({ text: 'Bot Moderation Panel' })
            .setTimestamp();

        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('panel_kick').setLabel('Kick Member').setStyle(ButtonStyle.Primary).setEmoji('👢'),
            new ButtonBuilder().setCustomId('panel_ban').setLabel('Ban Member').setStyle(ButtonStyle.Danger).setEmoji('🔨'),
            new ButtonBuilder().setCustomId('panel_mute').setLabel('Mute Member').setStyle(ButtonStyle.Secondary).setEmoji('🔇'),
            new ButtonBuilder().setCustomId('panel_warn').setLabel('Warn Member').setStyle(ButtonStyle.Secondary).setEmoji('⚠️')
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('panel_purge').setLabel('Purge Messages').setStyle(ButtonStyle.Primary).setEmoji('🗑️'),
            new ButtonBuilder().setCustomId('panel_slowmode').setLabel('Set Slowmode').setStyle(ButtonStyle.Secondary).setEmoji('🐢'),
            new ButtonBuilder().setCustomId('panel_lock').setLabel('Lock Channel').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
            new ButtonBuilder().setCustomId('panel_unlock').setLabel('Unlock Channel').setStyle(ButtonStyle.Success).setEmoji('🔓')
        );

        const row3 = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('panel_logs')
                .setPlaceholder('View Recent Logs')
                .addOptions([
                    { label: 'Recent Bans', value: 'bans', description: 'View recent ban actions' },
                    { label: 'Recent Kicks', value: 'kicks', description: 'View recent kick actions' },
                    { label: 'Recent Warns', value: 'warns', description: 'View recent warnings' },
                    { label: 'Recent Mutes', value: 'mutes', description: 'View recent mutes' }
                ])
        );

        await interaction.editReply({ embeds: [embed], components: [row1, row2, row3] });
    }
};
