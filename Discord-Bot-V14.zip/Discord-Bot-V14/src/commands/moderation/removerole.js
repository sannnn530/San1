const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ManageRoles],
        perms: [Discord.PermissionsBitField.Flags.ManageRoles]
    }, interaction);

    if (perms == false) return;

    const user = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
        return client.errNormal({ error: 'User not found in this server!', type: 'editreply' }, interaction);
    }

    if (role.position >= interaction.guild.members.me.roles.highest.position) {
        return client.errNormal({ error: 'I cannot remove this role (role is higher than my highest role)!', type: 'editreply' }, interaction);
    }

    if (!member.roles.cache.has(role.id)) {
        return client.errNormal({ error: 'User does not have this role!', type: 'editreply' }, interaction);
    }

    await member.roles.remove(role);

    client.succNormal({
        text: `Removed role **${role.name}** from **${user.tag}**`,
        type: 'editreply'
    }, interaction);
};
