const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ModerateMembers],
        perms: [Discord.PermissionsBitField.Flags.ModerateMembers]
    }, interaction);

    if (perms == false) return;

    const user = interaction.options.getUser('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = interaction.guild.members.cache.get(user.id);
    if (!member) {
        return client.errNormal({ error: 'User not found in this server!', type: 'editreply' }, interaction);
    }

    if (!member.moderatable) {
        return client.errNormal({ error: 'I cannot mute this user!', type: 'editreply' }, interaction);
    }

    const match = durationStr.match(/^(\d+)(m|h|d)$/);
    if (!match) {
        return client.errNormal({ error: 'Invalid duration format! Use: 1m, 1h, or 1d', type: 'editreply' }, interaction);
    }

    const amount = parseInt(match[1]);
    const unit = match[2];
    let ms;
    if (unit === 'm') ms = amount * 60 * 1000;
    else if (unit === 'h') ms = amount * 60 * 60 * 1000;
    else if (unit === 'd') ms = amount * 24 * 60 * 60 * 1000;

    if (ms > 28 * 24 * 60 * 60 * 1000) {
        return client.errNormal({ error: 'Duration cannot exceed 28 days!', type: 'editreply' }, interaction);
    }

    await member.timeout(ms, reason);

    client.succNormal({
        text: `**${user.tag}** has been muted for ${durationStr}`,
        fields: [
            { name: 'Reason', value: reason, inline: true },
            { name: 'Moderator', value: `${interaction.user.tag}`, inline: true }
        ],
        type: 'editreply'
    }, interaction);
};
