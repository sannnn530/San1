const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ManageMessages],
        perms: [Discord.PermissionsBitField.Flags.ManageMessages]
    }, interaction);

    if (perms == false) return;

    const type = interaction.options.getString('type');
    const amount = Math.min(interaction.options.getNumber('amount'), 100);

    if (amount < 1) {
        return client.errNormal({ error: 'Amount must be at least 1!', type: 'editreply' }, interaction);
    }

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    let filtered;

    switch (type) {
        case 'bots':
            filtered = messages.filter(m => m.author.bot);
            break;
        case 'links':
            filtered = messages.filter(m => /(https?:\/\/[^\s]+)/g.test(m.content));
            break;
        case 'images':
            filtered = messages.filter(m => m.attachments.size > 0);
            break;
        case 'embeds':
            filtered = messages.filter(m => m.embeds.length > 0);
            break;
        default:
            filtered = messages;
    }

    const toDelete = [...filtered.values()].slice(0, amount).filter(m => {
        const age = Date.now() - m.createdTimestamp;
        return age < 14 * 24 * 60 * 60 * 1000;
    });

    if (toDelete.length === 0) {
        return client.errNormal({ error: 'No messages found to delete!', type: 'editreply' }, interaction);
    }

    await interaction.channel.bulkDelete(toDelete, true);

    client.succNormal({
        text: `Deleted **${toDelete.length}** ${type} messages`,
        type: 'editreply'
    }, interaction);
};
