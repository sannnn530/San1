const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ManageNicknames],
        perms: [Discord.PermissionsBitField.Flags.ManageNicknames]
    }, interaction);

    if (perms == false) return;

    const user = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname');
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
        return client.errNormal({ error: 'User not found in this server!', type: 'editreply' }, interaction);
    }

    if (!member.manageable) {
        return client.errNormal({ error: 'I cannot change this users nickname!', type: 'editreply' }, interaction);
    }

    const oldNick = member.nickname || member.user.username;
    await member.setNickname(nickname || null);

    if (nickname) {
        client.succNormal({
            text: `Changed **${user.tag}**'s nickname from **${oldNick}** to **${nickname}**`,
            type: 'editreply'
        }, interaction);
    } else {
        client.succNormal({
            text: `Reset **${user.tag}**'s nickname`,
            type: 'editreply'
        }, interaction);
    }
};
