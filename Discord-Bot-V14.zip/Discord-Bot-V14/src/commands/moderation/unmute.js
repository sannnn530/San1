const Discord = require('discord.js');

module.exports = async (client, interaction, args) => {
    const perms = await client.checkUserPerms({
        flags: [Discord.PermissionsBitField.Flags.ModerateMembers],
        perms: [Discord.PermissionsBitField.Flags.ModerateMembers]
    }, interaction);

    if (perms == false) return;

    const user = interaction.options.getUser('user');
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
        return client.errNormal({ error: 'User not found in this server!', type: 'editreply' }, interaction);
    }

    if (!member.isCommunicationDisabled()) {
        return client.errNormal({ error: 'This user is not muted!', type: 'editreply' }, interaction);
    }

    await member.timeout(null);

    client.succNormal({
        text: `**${user.tag}** has been unmuted`,
        fields: [
            { name: 'Moderator', value: `${interaction.user.tag}`, inline: true }
        ],
        type: 'editreply'
    }, interaction);
};
