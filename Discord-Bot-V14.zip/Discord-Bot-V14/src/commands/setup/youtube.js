const Discord = require('discord.js');
const Schema = require('../../database/models/youtube');

module.exports = async (client, interaction, args) => {
    const channel = interaction.options.getChannel('channel');
    const youtubeChannel = interaction.options.getString('youtube-channel');

    const data = await Schema.findOne({ Guild: interaction.guild.id, YouTubeChannel: youtubeChannel });

    if (data) {
        data.Channel = channel.id;
        await data.save();
        
        client.succNormal({
            text: `Updated YouTube notification channel to ${channel}!`,
            type: 'editreply'
        }, interaction);
    } else {
        new Schema({
            Guild: interaction.guild.id,
            Channel: channel.id,
            YouTubeChannel: youtubeChannel
        }).save();

        client.succNormal({
            text: `YouTube notifications for **${youtubeChannel}** will be posted in ${channel}!`,
            type: 'editreply'
        }, interaction);
    }
};
