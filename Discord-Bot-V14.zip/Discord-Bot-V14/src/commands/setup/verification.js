const Discord = require('discord.js');
const Schema = require('../../database/models/verification');

module.exports = async (client, interaction, args) => {
    const channel = interaction.options.getChannel('channel');
    const role = interaction.options.getRole('role');

    const data = await Schema.findOne({ Guild: interaction.guild.id });

    if (data) {
        data.Channel = channel.id;
        data.Role = role.id;
        data.Enabled = true;
        await data.save();
    } else {
        new Schema({
            Guild: interaction.guild.id,
            Channel: channel.id,
            Role: role.id,
            Enabled: true
        }).save();
    }

    const verifyButton = new Discord.ButtonBuilder()
        .setCustomId('Bot_verify')
        .setLabel('Verify')
        .setStyle(Discord.ButtonStyle.Success)
        .setEmoji('✅');

    const row = new Discord.ActionRowBuilder().addComponents(verifyButton);

    const embed = new Discord.EmbedBuilder()
        .setTitle('Verification Required')
        .setDescription('Click the button below to verify yourself and gain access to the server!')
        .setColor(client.config.colors.normal)
        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

    await channel.send({ embeds: [embed], components: [row] });

    client.succNormal({
        text: `Verification system has been set up in ${channel}!\nVerified members will receive the ${role} role.`,
        type: 'editreply'
    }, interaction);
};
