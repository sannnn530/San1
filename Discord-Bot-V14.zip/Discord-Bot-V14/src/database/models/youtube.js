const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    Guild: String,
    Channel: String,
    YouTubeChannel: String,
    LastVideoId: String,
    Message: { type: String, default: "New video from {channel}: {title}\n{url}" }
});

module.exports = mongoose.model("youtube", Schema);
