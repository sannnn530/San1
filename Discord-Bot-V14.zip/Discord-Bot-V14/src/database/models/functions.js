const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    Guild: String,
    Levels: { type: Boolean, default: false },
    Beta: { type: Boolean, default: false },
    AntiAlt: { type: Boolean, default: false },
    AntiSpam: { type: Boolean, default: false },
    AntiCaps: { type: Boolean, default: false },
    AntiInvite: { type: Boolean, default: false },
    AntiLinks: { type: Boolean, default: false },
    AntiMassMention: { type: Boolean, default: false },
    MessageLogs: { type: Boolean, default: true },
    ModLogs: { type: Boolean, default: false },
    WelcomeEnabled: { type: Boolean, default: false },
    LeaveEnabled: { type: Boolean, default: false },
    LogChannel: String,
    DJRole: String,
    CommandLogDisabledChannels: { type: [String], default: [] },
    Prefix: String,
    Color: String,
    StaffAppEnabled: { type: Boolean, default: false },
    StaffAppQuestions: { type: [String], default: [] },
    CommandPermissions: { type: Object, default: {} }
});

module.exports = mongoose.model("functions", Schema);