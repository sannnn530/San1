const mongoose = require('mongoose');

const Schema = new mongoose.Schema({
    Guild: String,
    Channel: String,
    Role: String,
    Message: String,
    Enabled: { type: Boolean, default: false }
});

module.exports = mongoose.model("verification", Schema);
