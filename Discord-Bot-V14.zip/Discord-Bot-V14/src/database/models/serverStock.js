const mongoose = require('mongoose');

const StockItemSchema = new mongoose.Schema({
    type: String,
    stock: { type: Number, default: 0 },
    maxStock: { type: Number, default: 100 },
    price: { type: Number, default: 0 },
    lastRestock: { type: Date, default: Date.now }
}, { _id: false });

const Schema = new mongoose.Schema({
    Guild: { type: String, required: true, unique: true },
    Baits: { type: [StockItemSchema], default: [] },
    Rods: { type: [StockItemSchema], default: [] },
    LastGlobalRestock: { type: Date, default: Date.now },
    RestockInterval: { type: Number, default: 3600000 }
});

Schema.statics.getOrCreate = async function(guildId) {
    let data = await this.findOne({ Guild: guildId });
    if (!data) {
        data = await this.create({ Guild: guildId });
        await data.initializeStock();
    }
    return data;
};

Schema.methods.initializeStock = async function() {
    const baitTypes = ['basic', 'worm', 'cricket', 'grub', 'beetle', 'minnow', 'premium', 'super', 'mega', 'ultra', 'legendary', 'golden', 'cosmic', 'transcendent'];
    const baitPrices = {
        basic: 20, worm: 25, cricket: 30, grub: 35, beetle: 40, minnow: 50,
        premium: 800, super: 900, mega: 1000, ultra: 1200,
        legendary: 10000, golden: 12000, cosmic: 70000, transcendent: 1000000
    };
    
    const rodTypes = ['basic', 'wooden', 'pine', 'oak', 'bamboo', 'maple', 'fiberglass', 'graphite', 'carbon', 'titanium', 'gold', 'diamond'];
    const rodPrices = {
        basic: 100, wooden: 200, pine: 350, oak: 500, bamboo: 750, maple: 1000,
        fiberglass: 2000, graphite: 3000, carbon: 4000, titanium: 28000, gold: 40000, diamond: 550000
    };
    
    this.Baits = baitTypes.map(type => ({
        type,
        stock: Math.floor(Math.random() * 80) + 20,
        maxStock: type.includes('legendary') || type.includes('transcendent') ? 10 : (type.includes('cosmic') || type.includes('golden') ? 25 : 100),
        price: baitPrices[type] || 20
    }));
    
    this.Rods = rodTypes.map(type => ({
        type,
        stock: Math.floor(Math.random() * 8) + 2,
        maxStock: type === 'diamond' ? 2 : (type === 'gold' || type === 'titanium' ? 5 : 15),
        price: rodPrices[type] || 100
    }));
    
    await this.save();
};

Schema.methods.randomRestock = async function() {
    const now = Date.now();
    if (now - this.LastGlobalRestock.getTime() < this.RestockInterval) {
        return false;
    }
    
    const baseBaitPrices = {
        basic: 20, worm: 25, cricket: 30, grub: 35, beetle: 40, minnow: 50,
        premium: 800, super: 900, mega: 1000, ultra: 1200,
        legendary: 10000, golden: 12000, cosmic: 70000, transcendent: 1000000
    };
    
    const baseRodPrices = {
        basic: 100, wooden: 200, pine: 350, oak: 500, bamboo: 750, maple: 1000,
        fiberglass: 2000, graphite: 3000, carbon: 4000, titanium: 28000, gold: 40000, diamond: 550000
    };
    
    for (const bait of this.Baits) {
        const restockChance = Math.random();
        if (restockChance > 0.3) {
            const restockAmount = Math.floor(Math.random() * (bait.maxStock * 0.5)) + 5;
            bait.stock = Math.min(bait.maxStock, Math.max(0, bait.stock + restockAmount));
            const basePrice = baseBaitPrices[bait.type] || 20;
            bait.price = Math.max(Math.floor(basePrice * 0.7), Math.min(Math.floor(basePrice * 1.5), Math.floor(bait.price * (0.85 + Math.random() * 0.3))));
            bait.lastRestock = new Date();
        }
    }
    
    for (const rod of this.Rods) {
        const restockChance = Math.random();
        if (restockChance > 0.5) {
            const restockAmount = Math.floor(Math.random() * (rod.maxStock * 0.3)) + 1;
            rod.stock = Math.min(rod.maxStock, Math.max(0, rod.stock + restockAmount));
            const basePrice = baseRodPrices[rod.type] || 100;
            rod.price = Math.max(Math.floor(basePrice * 0.7), Math.min(Math.floor(basePrice * 1.5), Math.floor(rod.price * (0.9 + Math.random() * 0.2))));
            rod.lastRestock = new Date();
        }
    }
    
    this.LastGlobalRestock = new Date();
    await this.save();
    return true;
};

Schema.methods.buyItem = async function(itemType, category, quantity) {
    const items = category === 'bait' ? this.Baits : this.Rods;
    const item = items.find(i => i.type === itemType);
    
    if (!item) return { success: false, error: 'Item not found in stock' };
    if (item.stock < quantity) return { success: false, error: `Only ${item.stock} available in stock`, available: item.stock };
    
    item.stock = Math.max(0, item.stock - quantity);
    await this.save();
    
    return { success: true, price: item.price, remaining: item.stock };
}

Schema.methods.getItemPrice = function(itemType, category) {
    const items = category === 'bait' ? this.Baits : this.Rods;
    const item = items.find(i => i.type === itemType);
    return item ? item.price : null;
}

Schema.methods.getItemStock = function(itemType, category) {
    const items = category === 'bait' ? this.Baits : this.Rods;
    const item = items.find(i => i.type === itemType);
    return item ? { stock: item.stock, maxStock: item.maxStock, price: item.price } : null;
};

module.exports = mongoose.model("serverStock", Schema);
