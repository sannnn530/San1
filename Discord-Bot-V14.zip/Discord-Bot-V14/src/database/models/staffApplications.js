const mongoose = require('mongoose');

const staffApplicationSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    guildName: { type: String },
    userId: { type: String, required: true },
    username: { type: String, required: true },
    avatar: { type: String },
    answers: { type: [String], default: [] },
    additional: { type: String },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    createdAt: { type: Date, default: Date.now },
    reviewedBy: { type: String },
    reviewedAt: { type: Date }
});

module.exports = mongoose.model('StaffApplication', staffApplicationSchema);
