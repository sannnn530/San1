const mongoose = require('mongoose');

const ItemStockSchema = new mongoose.Schema({
    itemType: String,
    itemId: String,
    currentStock: { type: Number, default: 0 },
    maxStock: { type: Number, default: 10 },
    lastRestock: { type: Date, default: Date.now },
    restockInterval: { type: Number, default: 3600000 }
}, { _id: false });

const Schema = new mongoose.Schema({
    Guild: String,
    Items: { type: [ItemStockSchema], default: [] },
    LastGlobalRestock: { type: Date, default: Date.now }
});

module.exports = mongoose.model("shopStock", Schema);
