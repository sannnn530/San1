const mongoose = require('mongoose');

const FishSchema = new mongoose.Schema({
    name: String,
    emoji: String,
    weight: Number,
    rarity: String,
    basePrice: Number
}, { _id: false });

const BaitSchema = new mongoose.Schema({
    type: String,
    quantity: Number
}, { _id: false });

const FishingRodSchema = new mongoose.Schema({
    type: String,
    durability: Number
}, { _id: false });

const AutoRestockSchema = new mongoose.Schema({
    baitType: String,
    minStock: Number,
    restockAmount: Number,
    enabled: { type: Boolean, default: true }
}, { _id: false });

const Schema = new mongoose.Schema({
    Guild: String,
    User: String,
    FishingRod: { type: Boolean, default: false },
    FishingRodType: { type: String, default: 'basic' },
    FishingRodUsage: { type: Number, default: 0 },
    FishingRods: { type: [FishingRodSchema], default: [] },
    Fish: { type: [FishSchema], default: [] },
    Bait: { type: [BaitSchema], default: [] },
    AutoRestock: { type: [AutoRestockSchema], default: [] },
    Boots: { type: String, default: null },
    Mask: { type: String, default: null },
    Gloves: { type: String, default: null },
    Lock: { type: String, default: null }
});

module.exports = mongoose.model("economyItems", Schema);