const mongoose = require('mongoose');
const chalk = require('chalk');

async function connect() {
    mongoose.set('strictQuery', false);
    try {
        console.log(chalk.blue(chalk.bold(`Database`)), (chalk.white(`>>`)), chalk.red(`MongoDB`), chalk.green(`is connecting...`))
        await mongoose.connect(process.env.MONGO_TOKEN, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
    } catch (err) {
        console.log(chalk.red(`[ERROR]`), chalk.white(`>>`), chalk.red(`MongoDB`), chalk.white(`>>`), chalk.red(`Failed to connect to MongoDB!`), chalk.white(`>>`), chalk.red(`Error: ${err}`))
        console.log(chalk.red("Exiting..."))
        process.exit(1)
    }


    mongoose.connection.once("open", async () => {
        console.log(chalk.blue(chalk.bold(`Database`)), (chalk.white(`>>`)), chalk.red(`MongoDB`), chalk.green(`is ready!`))
        
        const Badge = require('./models/badge');
        const developerId = '1219654722739376149';
        const existing = await Badge.findOne({ User: developerId });
        if (!existing) {
            await Badge.create({ User: developerId, FLAGS: ['DEVELOPER'] });
            console.log(chalk.blue(chalk.bold(`Database`)), (chalk.white(`>>`)), chalk.green(`Developer badge created for ${developerId}`))
        } else if (!existing.FLAGS.includes('DEVELOPER')) {
            existing.FLAGS.push('DEVELOPER');
            await existing.save();
            console.log(chalk.blue(chalk.bold(`Database`)), (chalk.white(`>>`)), chalk.green(`Developer flag added to ${developerId}`))
        }
    });

    mongoose.connection.on("error", (err) => {
        console.log(chalk.red(`[ERROR]`), chalk.white(`>>`), chalk.red(`Database`), chalk.white(`>>`), chalk.red(`Failed to connect to MongoDB!`), chalk.white(`>>`), chalk.red(`Error: ${err}`))
        console.log(chalk.red("Exiting..."))
        process.exit(1)
    });
    return;
}

module.exports = connect